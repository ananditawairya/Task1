import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { AccessGuard } from './access.guard';


const routes: Routes = [
  {path:"about",component:AboutComponent,canActivate:[AccessGuard]},
  {path:"contact/:cid",component:ContactComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
