import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angularProject';
  colorvar:string="red";
  applyborder:boolean=true;
  displayPara:boolean=false;
  customerDetails: any=[
    {name:'Jhon',id:1001},
    {name:'Jack',id:1002},
    {name:'Jim',id:1003},
  ]
  pcolorvar:string="red";
  borderdetails:string="2px solid blue";
  applyFirst:boolean=true;
  applySecond:boolean=true;
  fromParent:string="Data from Parent"
  datafromchild;
  changeTitle(newTitle){
    this.title=newTitle;
  }
  toggleBorderClass(){
    this.applyborder=this.applyborder?false:true;
  }

  UpdateFromChild($event){
    this.datafromchild=$event
  }
}
