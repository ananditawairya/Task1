import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'gender'
})
export class GenderPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    if(value=='M')
    return 'Male';
    else if(value=='F')
    return 'Female';
    
    //return null;
  }

}
