import { Component, OnInit,Input,Output, EventEmitter} from '@angular/core';
import { MainService } from './main.service';
// import {HttpClient} from '@angular/common/http'
@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  username:string;
  password:string;
  successMessage:string;
  errorMessage:string;
  mainService;
// MainServiceInstance=new MainService();
 response;

 @Input()
 toChild;

 @Output()
 fromChild : EventEmitter<string>=new EventEmitter<string>()
  constructor(private  MainServiceInstance : MainService ) { }

  ngOnInit() {
  }

  funInChild(){
    this.fromChild.emit("Hey there ! I am from Child Component!")
  }
  login(){
    if(this.username=='admin'&&this.password=='admin123'){
      this.successMessage="Login Successfully!"
      this.errorMessage=""
    }
    else{
      this.errorMessage="Login failed! Please enter correct credentials"
      this.successMessage=""
    }
  }
  getDetails(){
    // this.mainService=this.MainServiceInstance.getData();
    // console.log(this.mainService)
    this.MainServiceInstance.getData().subscribe(
      (success)=>{this.mainService=success},
      (error)=>{console.log(error.error.message)}
    )
  
  }
}
