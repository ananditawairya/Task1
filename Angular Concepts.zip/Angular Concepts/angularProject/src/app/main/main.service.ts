import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {Observable} from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class MainService {

  constructor(private http:HttpClient) { }

  // getData(){
  //   let Data=[
  //     {"empNo":1001,"empName":"Jhon"},
  //     {"empNo":1002,"empName":"Jack"},
  //     {"empNo":1003,"empName":"Jill"},
  //     {"empNo":1004,"empName":"Jim"},
  //   ]

  //   return Data;
  // }
  getData():Observable<any>{
    
    return this.http.get<Observable<any>>("http://localhost:1080/getData")
  }

}
