import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-reactiveforms',
  templateUrl: './reactiveforms.component.html',
  styleUrls: ['./reactiveforms.component.css']
})
export class ReactiveformsComponent implements OnInit {

  constructor(public formBuilder: FormBuilder) { }

  formGroup=this.formBuilder.group({
    username:['',[Validators.required,Validators.minLength(4)]],
    password:['',[Validators.required,validatePassword]]
  })

  message:string;
  messageColor:string;

  ngOnInit() {
  }

  login(){
    let username=this.formGroup.controls.username.value;
    let pwd=this.formGroup.controls.password;
    if(username=='admin'){
      this.message="Login Successful";
      this.messageColor='green';
    }
    else{
      this.message="Login Failed";
      this.messageColor='red'; 
    }
  }
}

function validatePassword(fc:FormControl){
  let pwd=fc.value;
  if(pwd='admin'){
    return{
      pwderror:{
        message:'Invalid password'
      }
    }
  }
  else
  return null
}
