import { Component } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  bookOptionSelected: boolean = false;
  agree: boolean = false;
  dable: boolean = false;

  constructor(private router: Router) { }

  // selected() {
  //   this.bookOptionSelected = true;
  //   this.dable=false;
  //   this.router.navigate(['/book']  );
  // }

  agreed(val) {
    if (val == 1) {
      this.agree = true;
      this.router.navigate(['/book']);
    }
    else if (val == 2) {
      this.agree = true;
      this.router.navigate(['/view']);
    }
    else if (val == 3) {
      this.agree = true;
      this.router.navigate(['/verify'])
    }
  }
}