import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { BookFlightService } from "./book-flight.service";

@Component({
  selector: 'app-book-flight',
  templateUrl: './book-flight.component.html',
  styleUrls: ['./book-flight.component.css'],
  providers: [BookFlightService]
})
export class BookFlightComponent implements OnInit {

  errorMessage: String;
  successMessage: String;

  constructor(private fb: FormBuilder, private bookFlightService: BookFlightService) { }

  bookingForm = this.fb.group({
    passengerName: ["", [Validators.required,Validators.pattern(/^[A-Za-z][a-zA-Z ]+$/)]],
    noOfTickets: ["", [Validators.required, Validators.min(1)]],
    flightId: ["", [Validators.required, validateFlight]]
  })

  ngOnInit() {
  }

  book() {
    this.successMessage = null;
    this.errorMessage = null;
    this.bookFlightService.bookFlight(this.bookingForm.value)
      .subscribe(
        response => {
          this.successMessage = response.message
        }, err => this.errorMessage = err.error.message);
  }
}

function validateFlight(c: FormControl) {
  let FLIGHT_REGEXP = /^[A-Z]{3}-[0-9]{3}$/;

  return FLIGHT_REGEXP.test(c.value) ? null : {
    flightError: {
      message: "Invalid flightID"
    }
  };
}


