import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FlightBooking } from '../shared/FlightBooking';


@Injectable()
export class BookFlightService {

  errorMessage: String;
  url = "http://localhost:1050/bookFlight"
  constructor(private http: HttpClient) { }

  bookFlight(data: any): Observable<any> {
    return <Observable<any>>this.http.post(this.url, data);
  }
}
