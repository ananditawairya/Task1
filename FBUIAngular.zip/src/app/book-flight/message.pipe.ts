import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'message'
})
export class MessagePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    var message="Flight booking successfull with booking Id :"+value;
    return message;
  }

}
