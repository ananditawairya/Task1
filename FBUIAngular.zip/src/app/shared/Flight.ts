export class Flights{
    flightId:any; 
    aircraftName:any; 
    fare:any; 
    availableSeats:any; 
    status:any;
}