import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { UpdateBookingService } from './update-booking.service';

@Component({
  selector: 'app-update-booking',
  templateUrl: './update-booking.component.html',
  styleUrls: ['./update-booking.component.css']
})
export class UpdateBookingComponent implements OnInit {

  updateBookingForm: FormGroup;
  constructor(private fb: FormBuilder, private route: ActivatedRoute, private updateBookingServ: UpdateBookingService) {
  }
  bookingId; flightId;
  successMessage; errorMessage;
  updateBooking() {
    this.successMessage = this.errorMessage = null;
    let formObj = { bookingId: this.bookingId, flightId: this.flightId, noOfTickets: this.updateBookingForm.value.noOfTickets }
    this.updateBookingServ.updateBooking(formObj).subscribe(
      response => this.successMessage = response.message, (err) => this.errorMessage = err.error.message)
  }

  ngOnInit() {

    this.route.params.subscribe(param => {
      console.log('here', param);
      this.bookingId = param.bookingId
      this.flightId = param.flightId
    })
    this.updateBookingForm = this.fb.group({
      bookingId: [{ value: this.bookingId, disabled: true }, [Validators.required, Validators.min(2001)]],
      noOfTickets: ["", [Validators.required, Validators.min(1)]],
      flightId: [{ value: this.flightId, disabled: true }, [Validators.required, validateFlight]]
    })
  }
}

function validateFlight(c: FormControl) {
  let FLIGHT_REGEXP = /^[A-Z]{3}-[0-9]{3}$/;

  return FLIGHT_REGEXP.test(c.value) ? null : {
    flightError: {
      message: "Invalid flightID"
    }
  };
}