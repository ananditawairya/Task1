import { TestBed } from '@angular/core/testing';

import { UpdateBookingService } from './update-booking.service';

describe('UpdateBookingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UpdateBookingService = TestBed.get(UpdateBookingService);
    expect(service).toBeTruthy();
  });
});
