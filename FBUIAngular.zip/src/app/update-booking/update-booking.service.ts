import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class UpdateBookingService {

  constructor(private http: HttpClient) { }

  updateBooking(data): Observable<any> {
    console.log(data);
    return this.http.put<any>("http://localhost:1050/updateBooking/" + data.bookingId, data);
  }
}
