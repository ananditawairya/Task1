import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormsModule } from '@angular/forms';
import { ViewDetailsService } from "./view-details.service";
import { FlightBooking } from '../shared/FlightBooking';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css'],
  providers: [ViewDetailsService]
})
export class ViewDetailsComponent implements OnInit {

  flightDetails: FlightBooking[];
  successMessage: String;
  errorMessage: String;


  constructor(private fb: FormBuilder, private viewdetailsservice: ViewDetailsService, private router: Router) { }

  viewbookingForm = this.fb.group({
    bookingId: ['', [Validators.required, Validators.min(4)]],
  })

  ngOnInit() {
    this.view();
  }

  updateBooking(flightBooking) {
    this.router.navigate(["/updateBooking", flightBooking])
  }

  view() {
    this.successMessage = null;
    this.errorMessage = null;
    this.viewdetailsservice.view().subscribe(
      flightDetails => { this.flightDetails = flightDetails; });
  }

  delete(bookingId) {
    this.viewdetailsservice.delete(bookingId).subscribe(
      res => {
        this.successMessage = res.message;
        this.flightDetails = this.flightDetails.filter((data) => data.bookingId != bookingId)
      },
      error => this.errorMessage = error.error.message
    )
  }
}

