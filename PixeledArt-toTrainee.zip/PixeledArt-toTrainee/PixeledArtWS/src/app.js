var express = require('express');
var create = require('./model/dbsetup')
var bodyParser = require('body-parser');
var router = require('./routes/routing');
var myErrorLogger = require('./utilities/errorlogger');
var myRequestLogger = require('./utilities/requestlogger');

var cors = require('cors');
var app = express();
app.use(cors());

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(myRequestLogger);

app.use('/', router);

//for setting up the DB
app.get('/setupDb', (req, res, next) => {
    create.setupDb().then((data) => {
        res.send(data)
    }).catch((err) => {
        next(err)
    })
})

app.use(myErrorLogger);

app.listen(3080);
console.log("Server listening in port 3080");

module.exports = app;