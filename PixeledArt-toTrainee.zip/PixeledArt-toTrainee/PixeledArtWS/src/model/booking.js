class Booking {
    constructor(obj) {
        this.bookingId = obj.bookingId;
        this.eventName = obj.eventName;
        this.noOfTickets = obj.noOfTickets
        this.fare = obj.fare
        this.eventTime = obj.eventTime
        this.mealsIncluded = obj.mealsIncluded
    }
}
module.exports = Booking;