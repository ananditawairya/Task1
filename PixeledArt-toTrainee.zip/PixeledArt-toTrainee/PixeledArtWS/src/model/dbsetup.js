let today = new Date();
let year = today.getFullYear();
let month = today.getMonth();
let day = today.getDate();

BookingCollectionDocument = [
    {
        emailId: 'steve@infy.com',
        "eventDetails": [{
            "eventName": 'Ignorance is Bliss',
            "fare": 5999,
            "bookingId": 1001,
            "noOfTickets": 2,
            "eventTime": "Morning",
            "mealsIncluded": true
        },
        {
            "eventName": 'Ignorance is Bliss',
            "fare": 5999,
            "bookingId": 1002,
            "noOfTickets": 2,
            "eventTime": "Morning",
            "mealsIncluded": true
        }, 
        {
            "eventName": 'Ignorance is Bliss',
            "fare": 5999,
            "bookingId": 1003,
            "noOfTickets": 2,
            "eventTime": "Morning",
            "mealsIncluded": true
        }
        ]
    },
    {
        emailId: 'sango@infy.com',
        "eventDetails": [{
            "eventName": 'Ignorance is Bliss',
            "fare": 5499,
            "bookingId": 1004,
            "noOfTickets": 2,
            "eventTime": "Morning",
        }]
    },
    {
        emailId: 'zim@infy.com',
        "eventDetails": [{
            "eventName": 'Ignorance is Bliss',
            "fare": 5249,
            "bookingId": 1005,
            "noOfTickets": 2,
            "eventTime": "Evening"
        }]
    },
    {
        emailId: 'john@infy.com',
        "eventDetails": [{
            "eventName": 'Ignorance is Bliss',
            "fare": 5999,
            "bookingId": 1006,
            "noOfTickets": 2,
            "eventTime": "Morning",
            "mealsIncluded": true
        }]
    },
    {
        emailId: 'barny@infy.com',
        "eventDetails": []
    }
]

DetailsCollectionDocument =[
    {
        eventName: "Out of the blue",
        eventDate: new Date('09-12-2019'),
        fare: 6449,
        availability: 10,
        eventImage: "assets/outOfTheBlue.jpg",
        aboutEvent: "Photography Bootcamp - With Sukla Chinnappa"
    },
    {
        eventName: "Ignorance is Bliss",
        eventDate: new Date('11-12-2019'),
        fare: 4999,
        availability: 10,
        eventImage: "assets/ignoranceIsBliss.jpg",
        aboutEvent: "Fashion Photography Workshop - With Jack Hugh"
    },
    {
        eventName: "Rains of Castamere",
        eventDate: new Date('12-12-2019'),
        fare: 2499,
        availability: 10,
        eventImage: "assets/RainsOfCastamere.jpg",
        aboutEvent: "Art and Science of Photography Workshop - With Toehold"
    }
    
]


let collection = require('../utilities/connection');

exports.setupDb = () => {
    return collection.getDetailsCollection().then(detailsModel => {
        return detailsModel.deleteMany().then(data => {
            return detailsModel.insertMany(DetailsCollectionDocument).then((data) => {
                if (data.length > 0) {
                    return collection.getBookingCollection().then(bookingModel => {
                        return bookingModel.deleteMany({}).then(deletedData => {
                            return bookingModel.insertMany(BookingCollectionDocument).then(bookingData => {
                                if (bookingData.length > 0) return "Insertion Successfull"
                                else throw new Error("Database setup failed")
                            })
                        })
                    })
                } else throw new Error("Database setup failed");
            })
        })
    })
}
