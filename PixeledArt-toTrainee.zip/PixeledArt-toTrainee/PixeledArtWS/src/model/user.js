const collection = require('../utilities/connection');
let eventBookingDB = {}

eventBookingDB.generateId = () => {
    return collection.getBookingCollection().then(function (collection) {
        return collection.distinct("eventDetails.bookingId").then((bookingId) => {
            let max_booking_Id = Math.max(...bookingId);
            if (max_booking_Id > 0) return (max_booking_Id + 1);
            else return 1001
        })
    })
}

eventBookingDB.checkAvailability = (eventName) => {
    return collection.getDetailsCollection().then((database) => {
        return database.findOne({ "eventName": eventName }).then((eventDetails) => {
            if (eventDetails == null) return false;
            else return eventDetails;
        })
    })
}

eventBookingDB.bookEvent = (emailId, booking) => {
    return eventBookingDB.generateId().then((id) => {
        booking.bookingId = id
        return collection.getBookingCollection().then(bookingModel => {
            return bookingModel.updateOne({ "emailId": emailId },
                { $push: { eventDetails: booking } }, { runValidators: true, upsert: true }).then(updated => {
                    if (updated.upserted || updated.nModified > 0) return booking;
                    else return null
                })
        })
    })
}

eventBookingDB.updateAvailability = (eventName, newAvailability) => {
    return collection.getDetailsCollection().then((database) => {
        return database.updateOne({ "eventName": eventName }, { availability: newAvailability }).then((newDetails) => {
            if (newDetails.nModified == 1) return newDetails
            else return null
        })
    })
}

eventBookingDB.fetchBooking = (emailId) => {
    return collection.getBookingCollection().then((database) => {
        return database.findOne({ "emailId": emailId }, { _id: 0, eventDetails: 1 }).then(function (data) {
            if (data.eventDetails.length > 0) return data.eventDetails;
            else return null
        })
    })
}

eventBookingDB.cancelBooking = (toDelete, emailId) => {
    return collection.getBookingCollection().then(bookingModel => {
        return bookingModel.updateOne(
            { "emailId": emailId },
            { $pull: { eventDetails: { "bookingId": toDelete.bookingId } } }).then(pulled => {
                if (pulled.nModified > 0) {
                    return collection.getDetailsCollection().then(detailsModel => {
                        return detailsModel.updateOne({ eventName: toDelete.eventName }, { $inc: { availability: toDelete.noOfTickets } }).then(availabilityUpdate => {
                            if (availabilityUpdate.nModified > 0) return true
                            else return false
                        })
                    })
                } else return false;
            })
    })
}


eventBookingDB.fetchEvents = () => {
    return collection.getDetailsCollection().then((database) => {
        return database.find().then(allEvents => {
            if (allEvents != null) return allEvents
            else return null
        })
    })
}

module.exports = eventBookingDB;