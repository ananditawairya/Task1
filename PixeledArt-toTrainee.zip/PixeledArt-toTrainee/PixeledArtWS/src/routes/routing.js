const express = require('express');
const router = express.Router();
const service = require('../service/user');
const Booking = require('../model/booking')

router.get('/evaluate', (req, res, next) => {
  console.log("--Verification Started--");
  service.evaluate().then(data => {
    console.log("--Completed Successfully--");
    res.send(data)
  }).catch(err => {
    console.log("--Completed with Error--");
    next(err)
  })
})

router.put('/bookShow/:emailId', (req, res, next) => {
  let emailId = req.params.emailId
  let eventBooking = new Booking(req.body)
  service.bookEvent(emailId, eventBooking).then((obj) => {
    res.status(201)
    res.json({ "message": obj.noOfTickets + " tickets(s) booked with Booking ID- " + obj.bookingId + " for " + obj.eventName + " . Please Pay Rs." + obj.fare })
  }).catch((err) => next(err))
})

router.get('/fetchBooking/:emailId', (req, res, next) => {
  service.fetchBooking(req.params.emailId).then((bookingDetails) => {
    res.json(bookingDetails)
  }).catch((err) => next(err))
})

router.get('/fetchEvents', (req, res, next) => {
  service.fetchEvents().then((allEvents) => {
    res.json(allEvents)
  }).catch((err) => next(err))
})

router.delete('/cancelBooking/:emailId/:bookingId', (req, res, next) => {
  service.cancelBooking(req.params.bookingId, req.params.emailId).then((cancelStatus) => {
    res.json(cancelStatus)
  }).catch((err) => next(err))
})


module.exports = router;