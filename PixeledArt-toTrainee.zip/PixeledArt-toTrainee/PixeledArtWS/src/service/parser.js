// const fs = require('fs');
let parser = {}

parser.generateTestReport = (data) => {
    let testResult = {
        "totalTests": 0,
        "passed": 0,
        "failed": 0,
        "assertionReport": []
    }

    if (data !== {}) {
        let content = JSON.parse(data);
        testResult.totalTests = content.numTotalTests;
        testResult.passed = content.numPassedTests;
        testResult.failed = content.numFailedTests;

        let componentArray = []
        content.testResults[0].assertionResults.forEach(
            res => componentArray.indexOf(res.ancestorTitles[0]) === -1 ? componentArray.push(res.ancestorTitles[0]) : null
        );
        let final = []
        for (let i of componentArray) {
            let obj = { componentName: "", testCases: [] };
            for (let j of content.testResults[0].assertionResults) {
                if (i === j.ancestorTitles[0]) {
                    obj.componentName = j.ancestorTitles[0]
                    obj["testCases"].push({
                        testId: j.title.split("-")[0],
                        testName: j.title.split("-")[1],
                        testStatus: j.status
                    })
                }
            }
            final.push(obj)
        }

        testResult.assertionReport = final;
        return testResult;
    }
}

// let testData = require('../result.json')
// let final = parser.generateTestReport(testData)
// fs.writeFileSync('data.json', JSON.stringify(final))
// console.log(final);

module.exports = parser;