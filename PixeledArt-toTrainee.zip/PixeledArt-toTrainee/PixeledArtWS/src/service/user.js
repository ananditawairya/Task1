const model = require('../model/user');
const Validator = require('../utilities/validator');
const exec = require('child-process-promise').exec;
const fs = require('fs');
const path = require("path")
const parser = require("./parser");

let eventBookingService = {}

eventBookingService.evaluate = () => {
    evaluationPath = path.join(__dirname, "../../../pixeled-art-ui");
    // console.log("Begin testing!!");
    return exec(`cd ${evaluationPath} && npm test`)
        .then((response) => {
            let content = fs.readFileSync("../../pixeled-art-ui/result.json", 'utf8');
            return parser.generateTestReport(content);
        }).catch((err) => {
            let content = fs.readFileSync("../../pixeled-art-ui/result.json", 'utf8');
            return parser.generateTestReport(content);
        })
}


eventBookingService.calculatePrice = (eventBooking, fare) => {
    if (eventBooking.mealsIncluded) {
        if (eventBooking.eventTime === "Morning" || eventBooking.eventTime === "Afternoon") {
            return ((eventBooking.noOfTickets * fare) + 1000)
        } else if (eventBooking.eventTime === "Evening") {
            return ((eventBooking.noOfTickets * fare) + 750)
        } else {
            return ((eventBooking.noOfTickets * fare) + 500)
        }
    } else {
        if (eventBooking.eventTime === "Morning" || eventBooking.eventTime === "Afternoon") {
            return ((eventBooking.noOfTickets * fare) + 500)
        } else if (eventBooking.eventTime === "Evening") {
            return ((eventBooking.noOfTickets * fare) + 250)
        } else {
            return (eventBooking.noOfTickets * fare)
        }
    }
}

eventBookingService.bookEvent = (emailId, eventBooking) => {
    Validator.validateEventName(eventBooking.eventName);
    return model.checkAvailability(eventBooking.eventName).then((eventDetailsObj) => {
        if (eventDetailsObj && eventDetailsObj.availability < eventBooking.noOfTickets) {
            let err = new Error("Sorry only " + eventDetailsObj.availability + " seats available!");
            err.status = 403;
            throw err;
        } else {
            eventBooking.fare = eventBookingService.calculatePrice(eventBooking, eventDetailsObj.fare)
            return model.bookEvent(emailId, eventBooking).then((data) => {
                if (data != null) {
                    newAvailability = eventDetailsObj.availability - data.noOfTickets
                    return model.updateAvailability(eventBooking.eventName, newAvailability).then((newDetails) => {
                        if (newDetails != null) {
                            return data
                        } else {
                            let err = new Error("Error in saving details");
                            err.status = 400;
                            throw err;
                        }
                    })
                }
            })
        }
    })
}

eventBookingService.fetchBooking = (emailId) => {
    return model.fetchBooking(emailId).then(function (bookingData) {
        if (bookingData == null) {
            let err = new Error("No events booked for emailId: " + emailId)
            err.status = 404
            throw err;
        }
        else return bookingData;
    })
}

eventBookingService.cancelBooking = (bookingId, emailId) => {
    return model.fetchBooking(emailId).then(oldBookingData => {
        if (oldBookingData == null) {
            let err = new Error("Please enter a valid email id")
            err.status = 404
            throw err;
        } else {
            toDelete = oldBookingData.find(bookings => { return bookings.bookingId == bookingId });
            return model.cancelBooking(toDelete, emailId).then(data => {
                return data;
            })
        }
    })
}

eventBookingService.fetchEvents = () => {
    return model.fetchEvents().then((allEvents) => {
        if (allEvents == null) {
            let err = new Error("Could not fetch events please try again later!")
            err.status = 404
            throw err;
        } else return allEvents;
    })
}

module.exports = eventBookingService;

