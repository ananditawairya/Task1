const { Schema } = require("mongoose");
const Mongoose = require("mongoose")
Mongoose.Promise = global.Promise;
let url = "mongodb://localhost:27017/ArtDB";


let PixeledArtBookingSchema = Schema({
    emailId :String,
    "eventDetails": [
        {
            "eventName": {
                type: String,
                enum: ['Ignorance is Bliss', 'Rains of Castamere', 'Out of the blue'],
                required: true
            },
            "fare": {
                type: Number,
                required :true
            },
            bookingId: {
                type: Number,
                match: [/^[0-9]{4}$/,'Please enter a valid Booking ID'],
                required: true
            },
            noOfTickets: {
                type: Number,
                required: true
            },
            eventTime : {
                type: String,
                enum: ['Morning','Afternoon','Evening'],
                required: true
            },
            mealsIncluded : {
                type: Boolean
            }
        }
    ],
}, { collection: "PixeledArtBooking" })

let EventDetailsSchema = Schema({
    eventImage: String,
    "eventName": {
        type: String,
        enum: ['Ignorance is Bliss', 'Rains of Castamere', 'Out of the blue'],
        required: true
    },
    "eventDate":{
        type: Date,
        default: ()=>{
            if(this.eventName === 'Ignorance is Bliss'){
                return new Date('11-12-2019')
            } else if(this.eventName === 'Rains of Castamere'){
                return new Date('12-12-2019')
            } else if(this.eventName === 'Tryst with Destiny'){
                return new Date('09-12-2019')
            } else{
                return null
            }
        }
    },
    "fare": {
        type: Number,
        default: ()=>{
            if(this.eventName == 'Ignorance is Bliss'){
                return 4999
            } else if(this.eventName == 'Rains of Castamere'){
                return 2499
            } else if(this.eventName == 'Tryst with Destiny'){
                return 6449
            } else{
                return null
            }
        }
    },
    "availability":{
        type: Number,
        default: 10
    },
    "aboutEvent":{
        type: String
    }
}, { collection: "EventDetails" })


let collection = {};
collection.getBookingCollection = () => {
    return Mongoose.connect(url, { useNewUrlParser: true ,'useFindAndModify': false}).then((database) => {
        return database.model('PixeledArtBooking', PixeledArtBookingSchema)
    }).catch((error) => {
        let err = new Error("Could not connect to Database");
        err.status = 500;
        throw err;
    })
}
collection.getDetailsCollection = () => {
    return Mongoose.connect(url, { useNewUrlParser: true }).then((database) => {
        return database.model('EventDetails', EventDetailsSchema)
    }).catch((error) => {
        let err = new Error("Could not connect to Database");
        err.status = 500;
        throw err;
    })
}


module.exports = collection;