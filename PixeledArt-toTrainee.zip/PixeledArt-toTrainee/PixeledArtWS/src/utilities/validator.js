var Validator = {}


Validator.validateEventName = (eventName) => {
    let eventList = ['Ignorance is Bliss', 'Rains of Castamere', 'Out of the blue']
    if (eventList.indexOf(eventName) == -1) {
        let err = new Error("Invalid Show name")
        err.status = 406;
        throw err;
    }
}


module.exports = Validator;