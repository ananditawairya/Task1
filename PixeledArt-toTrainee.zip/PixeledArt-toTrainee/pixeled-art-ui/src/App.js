import React, { Component } from "react";
import Evaluator from "./components/evaluator";
import { BrowserRouter as Router, Link, Route} from "react-router-dom";
import "./App.css";
/* Import the necessary modules here */
import events from './components/events'
import ViewBookings from './components/ViewBooking'
import CreateBooking from './components/CreateBooking'

class App extends Component {
  render() {
    return (
      <React.Fragment>
        <Router>
          <Evaluator></Evaluator>
          <nav className="navbar navbar-expand-lg navbar-dark bg-custom">
            <span className="navbar-brand">Pixeled Art</span>
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link" to="/events">
                  Events
              </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/viewBookings">
                  View Bookings
              </Link>
              </li>
            </ul>
          </nav>
          {/* Implement the code for routing of components Here */}
          <div>
                    <Route exact path="/events" component={events}/>
                    <Route exact path="/viewBookings" component={ViewBookings}/>
                    <Route exact path="/CreateBooking" component={CreateBooking}/>
         </div>
        </Router>
      </React.Fragment>
    );
  }
}

export default App;