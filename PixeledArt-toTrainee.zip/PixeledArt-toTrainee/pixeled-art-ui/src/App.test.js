import React from "react";
import { shallow, mount } from "enzyme";
import { MemoryRouter } from "react-router";
import App from "./App";
import CreateBooking from "./components/CreateBooking";
import ViewBooking from "./components/ViewBooking";
import Events from "./components/events";
import MockAdapter from "axios-mock-adapter";

describe("Create Booking", () => {

    const selectedEvent = {
        eventName: "Event 1",
        aboutEvent: "Event is good",
        availability: 10,
        eventDate: "2020-01-01",
        fare: 3000

    }
    test("CBJT1 - CreateBooking component has a form", () => {
        const wrapper = shallow(<CreateBooking event={selectedEvent} />);
        var _0x127c = ["\x74\x6F\x48\x61\x76\x65\x4C\x65\x6E\x67\x74\x68", "\x66\x6F\x72\x6D", "\x66\x69\x6E\x64"]; expect(wrapper[_0x127c[2]](_0x127c[1]))[_0x127c[0]](1)
    });

    test("CBJT2 - CreateBooking component has 6 inputs (1 email, 1 number, 3 radio & 1 checkbox )", () => {
        const wrapper = shallow(<CreateBooking event={selectedEvent} />);
        var _0x2fa9 = ["\x6C\x65\x6E\x67\x74\x68", "\x69\x6E\x70\x75\x74\x5B\x74\x79\x70\x65\x3D\x22\x65\x6D\x61\x69\x6C\x22\x5D", "\x66\x69\x6E\x64", "\x66\x6F\x72\x6D", "\x69\x6E\x70\x75\x74\x5B\x74\x79\x70\x65\x3D\x22\x72\x61\x64\x69\x6F\x22\x5D", "\x69\x6E\x70\x75\x74\x5B\x74\x79\x70\x65\x3D\x22\x6E\x75\x6D\x62\x65\x72\x22\x5D", "\x69\x6E\x70\x75\x74\x5B\x74\x79\x70\x65\x3D\x22\x63\x68\x65\x63\x6B\x62\x6F\x78\x22\x5D", "\x74\x6F\x45\x71\x75\x61\x6C"]; let status = false; if (wrapper[_0x2fa9[2]](_0x2fa9[3])[_0x2fa9[2]](_0x2fa9[1])[_0x2fa9[0]] === 1 && wrapper[_0x2fa9[2]](_0x2fa9[3])[_0x2fa9[2]](_0x2fa9[4])[_0x2fa9[0]] === 3 && wrapper[_0x2fa9[2]](_0x2fa9[3])[_0x2fa9[2]](_0x2fa9[5])[_0x2fa9[0]] === 1 && wrapper[_0x2fa9[2]](_0x2fa9[3])[_0x2fa9[2]](_0x2fa9[6])[_0x2fa9[0]] === 1) { status = true }; expect(status)[_0x2fa9[7]](true)
    });

    test(`CBJT3 - CreateBooking component has a button of type submit and name book`, () => {
        const wrapper = shallow(<CreateBooking event={selectedEvent} />);
        var _0x1cb8 = ["\x74\x6F\x48\x61\x76\x65\x4C\x65\x6E\x67\x74\x68", "\x62\x75\x74\x74\x6F\x6E\x5B\x6E\x61\x6D\x65\x3D\x27\x62\x6F\x6F\x6B\x27\x5D", "\x66\x69\x6E\x64", "\x66\x6F\x72\x6D", "\x62\x75\x74\x74\x6F\x6E\x5B\x74\x79\x70\x65\x3D\x27\x73\x75\x62\x6D\x69\x74\x27\x5D"]; expect(wrapper[_0x1cb8[2]](_0x1cb8[3])[_0x1cb8[2]](_0x1cb8[1]) && wrapper[_0x1cb8[2]](_0x1cb8[3])[_0x1cb8[2]](_0x1cb8[4]))[_0x1cb8[0]](1)
    });

    test("CBJT4 - Name prop of all the input fields is proper in CreateBooking component", () => {
        const wrapper = shallow(<CreateBooking event={selectedEvent} />);
        var _0xdf49 = ["\x6E\x61\x6D\x65", "\x70\x72\x6F\x70\x73", "\x61\x74", "\x69\x6E\x70\x75\x74", "\x66\x69\x6E\x64", "\x66\x6F\x72\x6D", "\x65\x6D\x61\x69\x6C\x49\x64", "\x6E\x6F\x4F\x66\x54\x69\x63\x6B\x65\x74\x73", "\x65\x76\x65\x6E\x74\x54\x69\x6D\x65", "\x6D\x65\x61\x6C\x73", "\x74\x6F\x45\x71\x75\x61\x6C"]; let status = false; if (wrapper[_0xdf49[4]](_0xdf49[5])[_0xdf49[4]](_0xdf49[3])[_0xdf49[2]](0)[_0xdf49[1]]()[_0xdf49[0]] == _0xdf49[6] && wrapper[_0xdf49[4]](_0xdf49[5])[_0xdf49[4]](_0xdf49[3])[_0xdf49[2]](1)[_0xdf49[1]]()[_0xdf49[0]] == _0xdf49[7] && wrapper[_0xdf49[4]](_0xdf49[5])[_0xdf49[4]](_0xdf49[3])[_0xdf49[2]](2)[_0xdf49[1]]()[_0xdf49[0]] == _0xdf49[8] && wrapper[_0xdf49[4]](_0xdf49[5])[_0xdf49[4]](_0xdf49[3])[_0xdf49[2]](3)[_0xdf49[1]]()[_0xdf49[0]] == _0xdf49[8] && wrapper[_0xdf49[4]](_0xdf49[5])[_0xdf49[4]](_0xdf49[3])[_0xdf49[2]](4)[_0xdf49[1]]()[_0xdf49[0]] == _0xdf49[8] && wrapper[_0xdf49[4]](_0xdf49[5])[_0xdf49[4]](_0xdf49[3])[_0xdf49[2]](5)[_0xdf49[1]]()[_0xdf49[0]] == _0xdf49[9]) { status = true }; expect(status)[_0xdf49[10]](true)
    });

    test("CBJT5 - tags for error message of respective fields in CreateBooking component have appropriate name", () => {
        const wrapper = shallow(<CreateBooking event={selectedEvent} />);
        var _0xc5ec = ["\x6C\x65\x6E\x67\x74\x68", "\x5B\x6E\x61\x6D\x65\x3D\x22\x65\x6D\x61\x69\x6C\x49\x64\x45\x72\x72\x6F\x72\x22\x5D", "\x66\x69\x6E\x64", "\x5B\x6E\x61\x6D\x65\x3D\x22\x6E\x6F\x4F\x66\x54\x69\x63\x6B\x65\x74\x73\x45\x72\x72\x6F\x72\x22\x5D", "\x74\x6F\x45\x71\x75\x61\x6C"]; let emailIdError = wrapper[_0xc5ec[2]](_0xc5ec[1])[_0xc5ec[0]]; let noOfTicketsError = wrapper[_0xc5ec[2]](_0xc5ec[3])[_0xc5ec[0]]; expect(emailIdError + noOfTicketsError)[_0xc5ec[4]](2)
    });

    test("CBJT6 - tags for form level error and success messages in CreateBooking component have appropriate Name", () => {
        const wrapper = shallow(<CreateBooking event={selectedEvent} />);
        var _0x6e16=["\x6C\x65\x6E\x67\x74\x68","\x5B\x6E\x61\x6D\x65\x3D\x22\x65\x72\x72\x6F\x72\x4D\x65\x73\x73\x61\x67\x65\x22\x5D","\x66\x69\x6E\x64","\x5B\x6E\x61\x6D\x65\x3D\x22\x73\x75\x63\x63\x65\x73\x73\x4D\x65\x73\x73\x61\x67\x65\x22\x5D","\x74\x6F\x45\x71\x75\x61\x6C"];let errorMessage=wrapper[_0x6e16[2]](_0x6e16[1])[_0x6e16[0]];let successMessage=wrapper[_0x6e16[2]](_0x6e16[3])[_0x6e16[0]];expect(errorMessage+ successMessage)[_0x6e16[4]](2)
    });

    test("CBJT7 - email and noOfTickets fields have formcontrol class", () => {
        const wrapper = shallow(<CreateBooking event={selectedEvent} />);
        var _0x97ac=["\x66\x6F\x72\x6D\x2D\x63\x6F\x6E\x74\x72\x6F\x6C","\x68\x61\x73\x43\x6C\x61\x73\x73","\x69\x6E\x70\x75\x74\x5B\x6E\x61\x6D\x65\x3D\x22\x65\x6D\x61\x69\x6C\x49\x64\x22\x5D","\x66\x69\x6E\x64","\x69\x6E\x70\x75\x74\x5B\x6E\x61\x6D\x65\x3D\x22\x6E\x6F\x4F\x66\x54\x69\x63\x6B\x65\x74\x73\x22\x5D","\x74\x6F\x45\x71\x75\x61\x6C"];let emailId=wrapper[_0x97ac[3]](_0x97ac[2])[_0x97ac[1]](_0x97ac[0]);let noOfTickets=wrapper[_0x97ac[3]](_0x97ac[4])[_0x97ac[1]](_0x97ac[0]);expect(emailId&& noOfTickets)[_0x97ac[5]](true)
    });

    test("CBJT8 - eventTime and meals fields have appropriate bootstrap class", () => {
        const wrapper = shallow(<CreateBooking event={selectedEvent} />);
        var _0x78e7=["\x66\x6F\x72\x6D\x2D\x63\x68\x65\x63\x6B\x2D\x69\x6E\x70\x75\x74","\x68\x61\x73\x43\x6C\x61\x73\x73","\x61\x74","\x69\x6E\x70\x75\x74\x5B\x6E\x61\x6D\x65\x3D\x22\x65\x76\x65\x6E\x74\x54\x69\x6D\x65\x22\x5D","\x66\x69\x6E\x64","\x69\x6E\x70\x75\x74\x5B\x6E\x61\x6D\x65\x3D\x22\x6D\x65\x61\x6C\x73\x22\x5D","\x74\x6F\x45\x71\x75\x61\x6C"];let morning=wrapper[_0x78e7[4]](_0x78e7[3])[_0x78e7[2]](0)[_0x78e7[1]](_0x78e7[0]);let afterNoon=wrapper[_0x78e7[4]](_0x78e7[3])[_0x78e7[2]](1)[_0x78e7[1]](_0x78e7[0]);let evening=wrapper[_0x78e7[4]](_0x78e7[3])[_0x78e7[2]](2)[_0x78e7[1]](_0x78e7[0]);let meals=wrapper[_0x78e7[4]](_0x78e7[5])[_0x78e7[1]](_0x78e7[0]);expect(morning&& afterNoon&& evening&& meals)[_0x78e7[6]](true)
    });

    test("CBJT9 - any of validateField(), handleChange() or submitBooking() method returns a value, it should not", () => {
        const wrapper = shallow(<CreateBooking event={selectedEvent} />);
        var _0x9f03=["","\x76\x61\x6C\x69\x64\x61\x74\x65\x46\x69\x65\x6C\x64","\x69\x6E\x73\x74\x61\x6E\x63\x65","\x68\x61\x6E\x64\x6C\x65\x43\x68\x61\x6E\x67\x65","\x73\x75\x62\x6D\x69\x74\x42\x6F\x6F\x6B\x69\x6E\x67","\x74\x6F\x45\x71\x75\x61\x6C"];var event={target:{name:_0x9f03[0],value:_0x9f03[0]}};var event1={preventDefault:()=>{}};var status=false;let validateFieldData=wrapper[_0x9f03[2]]()[_0x9f03[1]]();let handleChangeData=wrapper[_0x9f03[2]]()[_0x9f03[3]](event);let submitBookingData=wrapper[_0x9f03[2]]()[_0x9f03[4]](event1);if(validateFieldData=== undefined&& handleChangeData=== undefined&& submitBookingData=== undefined){status= true};expect(status)[_0x9f03[5]](true)
    })

    test("CBJT10 - Event component loads on click of Back button", () => {
        const wrapper = shallow(<CreateBooking event={selectedEvent} />);
        var _0x165f=["\x63\x6C\x69\x63\x6B","\x73\x69\x6D\x75\x6C\x61\x74\x65","\x62\x75\x74\x74\x6F\x6E\x5B\x6E\x61\x6D\x65\x3D\x22\x62\x61\x63\x6B\x22\x5D","\x66\x69\x6E\x64","\x74\x6F\x48\x61\x76\x65\x4C\x65\x6E\x67\x74\x68"];wrapper[_0x165f[3]](_0x165f[2])[_0x165f[1]](_0x165f[0],{});expect(wrapper[_0x165f[3]](Events))[_0x165f[4]](1)
    })
})

describe("Events", () => {
    var _0x54f2=["\x61","","\x62","\x63"];const availableEvents=[{eventName:_0x54f2[0],aboutEvent:_0x54f2[1],eventImage:_0x54f2[1],eventDate:_0x54f2[1],eventFare:_0x54f2[1]},{eventName:_0x54f2[2],aboutEvent:_0x54f2[1],eventImage:_0x54f2[1],eventDate:_0x54f2[1],eventFare:_0x54f2[1]},{eventName:_0x54f2[3],aboutEvent:_0x54f2[1],eventImage:_0x54f2[1],eventDate:_0x54f2[1],eventFare:_0x54f2[1]}]

    test("ET1 - Event component has 3 cards with proper id", () => {
        const EventsWrapper = shallow(<Events />);
        var _0x5806=["\x73\x65\x74\x53\x74\x61\x74\x65","\x74\x6F\x48\x61\x76\x65\x4C\x65\x6E\x67\x74\x68","\x64\x69\x76\x5B\x69\x64\x3D\x27\x61\x27\x5D","\x66\x69\x6E\x64","\x64\x69\x76\x5B\x69\x64\x3D\x27\x62\x27\x5D","\x64\x69\x76\x5B\x69\x64\x3D\x27\x63\x27\x5D"];EventsWrapper[_0x5806[0]]({allEvents:availableEvents});expect(EventsWrapper[_0x5806[3]](_0x5806[2]))[_0x5806[1]](1);expect(EventsWrapper[_0x5806[3]](_0x5806[4]))[_0x5806[1]](1);expect(EventsWrapper[_0x5806[3]](_0x5806[5]))[_0x5806[1]](1)
    })

    test("ET2 - any of fetchEventDetails() or book() method returns a value, it should not", () => {
        const EventsWrapper = shallow(<Events />);
        var _0x63fd=["\x61","","\x66\x65\x74\x63\x68\x45\x76\x65\x6E\x74\x44\x65\x74\x61\x69\x6C\x73","\x69\x6E\x73\x74\x61\x6E\x63\x65","\x62\x6F\x6F\x6B","\x74\x6F\x45\x71\x75\x61\x6C"];var selectedEvent={eventName:_0x63fd[0],aboutEvent:_0x63fd[1],eventImage:_0x63fd[1],eventDate:_0x63fd[1],eventFare:_0x63fd[1]};var status=false;let fetchEventDetailsData=EventsWrapper[_0x63fd[3]]()[_0x63fd[2]]();let bookData=EventsWrapper[_0x63fd[3]]()[_0x63fd[4]](selectedEvent);if(fetchEventDetailsData=== undefined&& bookData=== undefined){status= true};expect(status)[_0x63fd[5]](true)
    })

    test("ET3 - CreateBooking component loads on click of Book button of an Event", () => {
        const EventsWrapper = shallow(<Events />);
        var _0x8dd2=["\x73\x65\x74\x53\x74\x61\x74\x65","\x63\x6C\x69\x63\x6B","\x61","","\x73\x69\x6D\x75\x6C\x61\x74\x65","\x61\x74","\x62\x75\x74\x74\x6F\x6E\x5B\x6E\x61\x6D\x65\x3D\x22\x62\x6F\x6F\x6B\x22\x5D","\x66\x69\x6E\x64","\x74\x6F\x48\x61\x76\x65\x4C\x65\x6E\x67\x74\x68"];EventsWrapper[_0x8dd2[0]]({allEvents:availableEvents});EventsWrapper[_0x8dd2[7]](_0x8dd2[6])[_0x8dd2[5]](0)[_0x8dd2[4]](_0x8dd2[1],{eventName:_0x8dd2[2],aboutEvent:_0x8dd2[3],eventImage:_0x8dd2[3],eventDate:_0x8dd2[3],eventFare:_0x8dd2[3]});expect(EventsWrapper[_0x8dd2[7]](CreateBooking))[_0x8dd2[8]](1)
    })

})

describe("View Booking", () => {

    test("VBJT1 - View Booking component form has one input(emailId) and 1 button(viewBookings)", () => {
        const wrapper = shallow(<ViewBooking />);
        var _0xaaa4=["\x74\x6F\x48\x61\x76\x65\x4C\x65\x6E\x67\x74\x68","\x69\x6E\x70\x75\x74\x5B\x6E\x61\x6D\x65\x3D\x22\x65\x6D\x61\x69\x6C\x49\x64\x22\x5D","\x66\x69\x6E\x64","\x62\x75\x74\x74\x6F\x6E\x5B\x6E\x61\x6D\x65\x3D\x22\x76\x69\x65\x77\x42\x6F\x6F\x6B\x69\x6E\x67\x73\x22\x5D"];expect(wrapper[_0xaaa4[2]](_0xaaa4[1]))[_0xaaa4[0]](1);expect(wrapper[_0xaaa4[2]](_0xaaa4[3]))[_0xaaa4[0]](1)
    });

    test("VBJT2 - Bookings should not be displayed on load of ViewBooking component", () => {
        const wrapper = shallow(<ViewBooking />);
        var _0x69d7=["\x74\x6F\x48\x61\x76\x65\x4C\x65\x6E\x67\x74\x68","\x74\x61\x62\x6C\x65","\x66\x69\x6E\x64"];expect(wrapper[_0x69d7[2]](_0x69d7[1]))[_0x69d7[0]](0)
    })

    test("VBJT3 - Bookings is displayed (with proper id) on View form submission, form should not be be displayed", () => {
        const wrapper = shallow(<ViewBooking />);
        var _0xa424=["\x73\x75\x62\x6D\x69\x74","\x73\x69\x6D\x75\x6C\x61\x74\x65","\x66\x6F\x72\x6D","\x66\x69\x6E\x64","\x61","\x62","\x73\x65\x74\x53\x74\x61\x74\x65","\x74\x6F\x48\x61\x76\x65\x4C\x65\x6E\x67\x74\x68","\x64\x69\x76\x5B\x69\x64\x3D\x31\x5D","\x64\x69\x76\x5B\x69\x64\x3D\x32\x5D"];wrapper[_0xa424[3]](_0xa424[2])[_0xa424[1]](_0xa424[0],{preventDefault:()=>{}});wrapper[_0xa424[6]]({bookingData:[{bookingId:1,eventName:_0xa424[4]},{bookingId:2,eventName:_0xa424[5]}]});expect(wrapper[_0xa424[3]](_0xa424[8]))[_0xa424[7]](1);expect(wrapper[_0xa424[3]](_0xa424[9]))[_0xa424[7]](1);expect(wrapper[_0xa424[3]](_0xa424[2]))[_0xa424[7]](0)
    })

    test("VBJT4 - Close button displayed with the bookings should have name as close", () => {
        const wrapper = shallow(<ViewBooking />);
        var _0xeca6=["\x73\x75\x62\x6D\x69\x74","\x73\x69\x6D\x75\x6C\x61\x74\x65","\x66\x6F\x72\x6D","\x66\x69\x6E\x64","\x61","\x62","\x73\x65\x74\x53\x74\x61\x74\x65","\x74\x6F\x48\x61\x76\x65\x4C\x65\x6E\x67\x74\x68","\x62\x75\x74\x74\x6F\x6E\x5B\x6E\x61\x6D\x65\x3D\x27\x63\x6C\x6F\x73\x65\x27\x5D"];wrapper[_0xeca6[3]](_0xeca6[2])[_0xeca6[1]](_0xeca6[0],{preventDefault:()=>{}});wrapper[_0xeca6[6]]({bookingData:[{bookingId:1,eventName:_0xeca6[4]},{bookingId:2,eventName:_0xeca6[5]}]});expect(wrapper[_0xeca6[3]](_0xeca6[8]))[_0xeca6[7]](1)
    })

    test("VBJT5 - View Details buttons displayed with the bookings should have name as viewDetails", () => {
        const wrapper = shallow(<ViewBooking />);
        var _0x7ccf=["\x73\x75\x62\x6D\x69\x74","\x73\x69\x6D\x75\x6C\x61\x74\x65","\x66\x6F\x72\x6D","\x66\x69\x6E\x64","\x61","\x62","\x73\x65\x74\x53\x74\x61\x74\x65","\x74\x6F\x48\x61\x76\x65\x4C\x65\x6E\x67\x74\x68","\x62\x75\x74\x74\x6F\x6E\x5B\x6E\x61\x6D\x65\x3D\x27\x76\x69\x65\x77\x44\x65\x74\x61\x69\x6C\x73\x27\x5D"];wrapper[_0x7ccf[3]](_0x7ccf[2])[_0x7ccf[1]](_0x7ccf[0],{preventDefault:()=>{}});wrapper[_0x7ccf[6]]({bookingData:[{bookingId:1,eventName:_0x7ccf[4]},{bookingId:2,eventName:_0x7ccf[5]}]});expect(wrapper[_0x7ccf[3]](_0x7ccf[8]))[_0x7ccf[7]](2)
    })

    test("VBJT6 - Cancel and Back button should be displayed only on click of viewDetails button", () => {
        const wrapper = shallow(<ViewBooking />);
        var _0x1fce=["\x73\x75\x62\x6D\x69\x74","\x73\x69\x6D\x75\x6C\x61\x74\x65","\x66\x6F\x72\x6D","\x66\x69\x6E\x64","\x61","\x62","\x73\x65\x74\x53\x74\x61\x74\x65","\x61\x74","\x62\x75\x74\x74\x6F\x6E\x5B\x6E\x61\x6D\x65\x3D\x27\x76\x69\x65\x77\x44\x65\x74\x61\x69\x6C\x73\x27\x5D","\x74\x6F\x48\x61\x76\x65\x4C\x65\x6E\x67\x74\x68","\x62\x75\x74\x74\x6F\x6E\x5B\x6E\x61\x6D\x65\x3D\x27\x63\x61\x6E\x63\x65\x6C\x27\x5D","\x62\x75\x74\x74\x6F\x6E\x5B\x6E\x61\x6D\x65\x3D\x27\x62\x61\x63\x6B\x27\x5D"];wrapper[_0x1fce[3]](_0x1fce[2])[_0x1fce[1]](_0x1fce[0],{preventDefault:()=>{}});wrapper[_0x1fce[6]]({bookingData:[{bookingId:1,eventName:_0x1fce[4]},{bookingId:2,eventName:_0x1fce[5]}]});wrapper[_0x1fce[3]](_0x1fce[8])[_0x1fce[7]](0)[_0x1fce[1]](_0x1fce[0],{preventDefault:()=>{}});wrapper[_0x1fce[6]]({selectedBooking:{bookingId:1,eventName:_0x1fce[4]}});expect(wrapper[_0x1fce[3]](_0x1fce[10]))[_0x1fce[9]](1);expect(wrapper[_0x1fce[3]](_0x1fce[11]))[_0x1fce[9]](1)
    })
})