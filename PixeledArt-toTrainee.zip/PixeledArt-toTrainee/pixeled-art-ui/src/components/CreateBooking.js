import React, { Component } from "react";
import "../App";
/* Import the necessary modules Here */
import Event from './events'
import axios from 'axios'


/* DO NOT ADD REMOVE OR ALTER ANY STATE OF THE COMPONENT */
class CreateBooking extends Component {
  constructor(props) {
    super(props);
    this.state = {
      form: {
        eventTime: "",
        emailId: "",
        noOfTickets: "",
        meals: false
      },
      formErrorMessage: {
        emailId: "",
        noOfTickets: "",
        eventTime: ""
      },
      formValid: {
        emailId: false,
        noOfTickets: false,
        eventTime: false,
        buttonActive: false
      },
      successMessage: "",
      errorMessage: "",
      bookingId: "",
      goBack: false
    };
  }

  submitBooking = (event) => {
    /*
    * Prevent Default page refresh 
    * Set the states successMessage and errorMessage to ""
    * Create an object with values of eventName, eventTime, noOfTickets, meals
    * Send an AXIOS PUT request to http://localhost:3080/bookShow/:emailId with created object as request body
    * Handle the success and error cases appropriately
    */
    event.preventDefault();
    const obj = {
      eventName: this.props.event.eventName,
      eventTime: this.state.form.eventTime,
      noOfTickets: this.state.form.noOfTickets,
      meals: this.state.form.meals
    }
    console.log(obj)
    console.log(this.state.form)
    axios.put("http://localhost:3080/bookShow/" + this.state.form.emailId, obj).then(response => {
      console.log("--------Response-----------");

      console.log(response)
      this.setState({
        successMessage: response.data.message,
        errorMessage: ""
      });
    })
      .catch(error => {
        if (error.response) {
          console.log(error.response)
          this.setState({ errorMessage: error.response.data.message, successMessage: "" });
        } else {
          this.setState({ errorMessage: "server error", successMessage: "" });
        }
      });

  }


  handleChange = (event) => {
    /*
    * Set the value entered into the input field to the corresponding state
    * Check if the input field is meals, then reset it to true if its value is false and viceversa
    * Invoke validateField method to validate the value entered
    * It should be invoked whenever the value in input field changes
    */
   let name=event.target.name;
   let value=event.target.value;
   let newState=this.state.form;
   if(name==="meals"){
    if(event.target.checked)
      value=true
     else value=false
   }
   newState[name]=value;
  
   
   this.validateField(name,value)
   this.setState({form:newState});
  }

  validateField = (fieldName, value) => {
    /*
    * Write appropriate logic to validate the input fields as per requirements given in the QP
    * ERROR MESSAGES are as given:-
    * Required Validation===> field required
    * Email Error===> Please enter valid email
    * No of tickets less than 1 Error==> No of tickets cannot be less than 1
    * No of tickets less than event availablity Error ==> Sorry only <<availability>> seat(s) available for this event
    * Reset the values of formValid, formErrorMessage successMessage and errorMessage state 
    */
   let FormValid=this.state.formValid;
   let FormErrorMessage=this.state.formErrorMessage;
   switch(fieldName){
     case "emailId":
     if(value===""|| value===null){
      FormValid.emailId=false;
      FormErrorMessage.emailId="field required"
   }
    else if(!(value.match(/^[A-Za-z]+[0-9]+[@][a-z]+[.][a-z]{2,3}$/))){
        FormValid.emailId=false;
        FormErrorMessage.emailId="Please enter a Valid Email with Capital as well as small letters along with digits";
     }
     else{
       FormValid.emailId=true;
       FormErrorMessage.emailId=""
     }
     break;
     case "noOfTickets":
     if(value===""|| value===null){
        FormValid.noOfTickets=false;
        FormErrorMessage.noOfTickets="field required"
     }
     else if((Number(value)<1)){
      FormValid.noOfTickets=false;
      FormErrorMessage.noOfTickets="No of tickets cannot be less than 1"
     }
     else if((Number(value)>this.props.event.availability)){
      FormValid.noOfTickets=false;
      FormErrorMessage.noOfTickets="Sorry only"+this.props.event.availability+ "seat(s) available for this event"
     }
     else{
       FormValid.noOfTickets=true;
       FormErrorMessage.noOfTickets=""
     }
     break;
     case "eventTime":
     if(value===""|| value===null){
      FormValid.eventTime=false;
      FormErrorMessage.eventTime="field required"
     }
     else{
       FormValid.eventTime=true;
       FormErrorMessage.eventTime=""
     }
     break;
     default:
     break;

   }
   FormValid.buttonActive=FormValid.emailId&&FormValid.eventTime&&FormValid.noOfTickets
   this.setState({formErrorMessage:FormErrorMessage})
   this.setState({formValid:FormValid})
  
  }

  render() {
    /* Load Events component on click of  goBack button by using appropriate state */
    return (
      this.state.goBack ? <Event /> :
      <React.Fragment>
        <div className="CreateBooking container-fluid">
          <div className="row">
            <div className="col-md-4 offset-md-4">
              <br />
              <div className="card">
                <div className="card-header bg-custom">
                  <h4>{this.props.event.eventName}</h4>
                  {this.props.event.aboutEvent}
                  <p><span>{new Date(this.props.event.eventDate).toDateString()} </span><span>Fare: &#x20b9;{this.props.event.fare}</span></p>
                </div>
                <div className="card-body">
                  {/* your code goes here to render the form as shown in the QP */}
                  <form onSubmit={this.submitBooking}>
                  <div className="form-group">
                    <label>Email Id </label>
                    <input type="email" name="emailId" className="form-control" onChange={this.handleChange} />
                  </div>
                  <span className="text-danger">{this.state.formErrorMessage.emailId}</span><br/>
                  <div className="form-group">
                    <label>Number of tickets</label>
                    <input type="number" name="noOfTickets" className="form-control" onChange={this.handleChange}/>
                  </div>
                  <span className="text-danger">{this.state.formErrorMessage.noOfTickets}</span><br/>
                  <div className="form-check-inline">
                    <label className="form-check-label">Event Time :&nbsp;&nbsp;</label>
                    <input type="radio" name="eventTime" className="form-check-input" value="Morning" onChange={this.handleChange} />Morning
                    </div>
                  <div className="form-check-inline">

                    <input type="radio" name="eventTime" className="form-check-input" value="Afternoon" onChange={this.handleChange} />Afternoon
                    </div>
                  <div className="form-check-inline">

                    <input type="radio" name="eventTime" className="form-check-input" value="Evening" onChange={this.handleChange}/>Evening
                    </div><br />
                    <span className="text-danger">{this.state.formErrorMessage.eventTime}</span><br/>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input className="form-check-input" type="checkbox" value="false" name="meals" onChange={this.handleChange}/>Include Meals</label>
                      
                  </div>

                  <button type="submit" className="btn btn-custom btn-block" disabled={!this.state.formValid.buttonActive}>Book</button>
                  <button type="button" className="btn btn-warning btn-block"onClick={()=>{this.setState({goBack:true})}}>Back</button>
                  <span className="text-success">{this.state.successMessage}</span><br/>
                  <span className="text-danger">{this.state.errorMessage}</span><br/>
                  </form>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default CreateBooking;