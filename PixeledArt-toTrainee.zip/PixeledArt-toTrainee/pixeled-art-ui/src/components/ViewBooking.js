import React, { Component } from "react";
import axios from "axios";
import "../App.css";

const fetchUrl = "http://localhost:3080/fetchBooking/";
const deleteUrl = "http://localhost:3080/cancelBooking/";

/* DO NOT ADD REMOVE OR ALTER ANY STATE OF THE COMPONENT */
class ViewBooking extends Component {
  constructor(props) {
    super(props);
    this.state = {
      emailId: "",
      bookingData: [],
      errorMessage: "",
      successMessage: "",
      selectedBooking: null
    };
  }

  cancelBookingbyId = (bookingId) => {
    /*
    * Reset the states errorMessage and successMessage to "" and selectedBooking to null
    * Send an Axios DELETE request to the url http://localhost:3080/cancelBooking/:emailId/:bookingId which returns true or false
    * Handle the success and error cases appropriately
    * Messages:-
    * "Sucessfully cancelled booking"
    * "Cancellation Failed"
    */
  }

  fetchBookingbyEmail = () => {
    const { emailId } = this.state;
    this.setState({ bookingData: [], errorMessage: "", successMessage: "" })
    axios.get(fetchUrl + emailId)
      .then(response => { this.setState({ bookingData: response.data }) })
      .catch(error => {
        if (error.response) this.setState({ errorMessage: error.response.data.message });
        else this.setState({ errorMessage: "server error" })
      });
  }

  onSearchChange = (event) => {
    /* Set emailId state with the value entered into the input field */
    let value=event.target.value;
    this.setState({emailId:value})

  }

  onSearchSubmit = (event) => {
    /* Prevent page refresh and then invoke fetchBookingbyEmail() method */
    event.preventDefault();
    this.fetchBookingbyEmail();
  }

  displayBookings = () => {
    /* 
     * Iterate over the bookingData state to create the cards.. 
     * The dummy code for each card is as given:-
     * <div key and id as mentioned>
     *    <div className="card bg-light">
     *        <div className="card-header">Booking ID:</div>
     *        <div className="card-body">
     *            <div className="row">
     *              <div className="col-8">
     *                  <h4>EVENT NAME</h4>
     *              </div>
     *              <div className="col-4">
     *                  <button className="btn btn-success btn-block"> View  Details </button>
     *              </div>
     *            </div>
     *        </div>
     *    </div>
     * </div>
     */
    
   {this.state.bookingData.map((data,key)=>
  //  console.log(data)
   <div className="card bg-light"key={data.bookingId}>
           <div className="card-header">Booking Details for {this.state.emailId}</div>
            <div className="card-body">
                <div className="row">
                  <div className="col-8">
                      <h4>{data.eventName}</h4>
                  </div>
                  <div className="col-4">
    
                      <button className="btn btn-success btn-block" onClick={this.onSearchChange}> View  Details</button>
    
                  </div>
                </div>
            </div>
    </div>
)}
   

  }

  displaySelectedBooking = () => {
    /*
    * It should create and return JSX to render a Card to display booking details as shown in QP
    * Modify the below code to achieve the desired result 
    */
    // <div className="card">
    //   <div className="card-header"> Booking ID:</div>
    //   <div className="card-body">
    //     <h5>Event Name: </h5>
    //     {/* CREATE THE TABLE WITH NECESSARY BOOKING DETAILS HERE */}
    //   </div>
    // </div>
  }

  render() {
    return (
      <React.Fragment>
        <form onSubmit={this.onSearchSubmit}>
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-6 offset-md-3">
              <br />
              <div className="card">
                <div className="card-header bg-custom text-center">
                  <h4>View Bookings</h4>
                </div>
                <div className="card-body view">
                  {/* 
                      CODE THE JSX here for conditional rendering of the view as mentioned in the QP
                      Use appropriate given states for achieving the result ... 
                      DO NOT CREATE ANY NEW STATE
                  */}
                  {this.displayBookings()}
                </div>
              </div>
            </div><br />
          </div>
        </div>
        </form>
      </React.Fragment>
    );
  }
}

export default ViewBooking;