import React, { Component } from 'react'
import "../App.css";
import axios from 'axios';

class Evaluator extends Component {
    constructor(props) {
        super(props);
        this.state = {
            dbMessage: null,
            testData: "",
        }
    }

    setUpDb = () => {
        this.setState({ dbMessage: null })
        axios.get("http://localhost:3080/setupDb").then(response => {
            this.setState({ dbMessage: response.data })
        }).catch(error => {
            if (error.response) {
                return error.response.data.message
            } else {
                return "server error"
            }
        })
    }

    displayComponentTabs = () => {
        let reportJSON = this.state.testData;
        var tabsArray = []; 
        if (reportJSON) {
            tabsArray = reportJSON.assertionReport.map((test, index) => {
                if (index === 0) {
                    return (
                        <li className="nav-item">
                            <a className="nav-link active" data-toggle="tab" href={"#tab" + index}>{test.componentName}</a>
                        </li>
                    )
                } else {
                    return (
                        <li className="nav-item">
                            <a className="nav-link" data-toggle="tab" href={"#tab" + index}>{test.componentName}</a>
                        </li>
                    )
                }
            })
            return tabsArray
        } else {
            console.log("something broke!!")
            return null
        }
    }

    displayTestReport = () => {
        let reportJSON = this.state.testData;
        let displayArray = [];
        if (reportJSON) {
            displayArray = reportJSON.assertionReport.map((test, index) => {
                if (index === 0) {
                    return (
                        <div id={"tab" + index} className="container tab-pane active"><br />
                            <table className="table table-bordered table-sm table-striped">
                                <thead>
                                    <th><h4>Test Status</h4></th>
                                    <th><h4>Test Name</h4></th>
                                </thead>
                                <tbody>
                                    {this.displayTableData(test)}
                                </tbody>
                            </table>
                        </div>
                    )
                } else {
                    return (
                        <div id={"tab" + index} className="container tab-pane"><br />
                            <table className="table table-bordered table-sm table-striped">
                                <thead>
                                    <tr>
                                        <th><h4>Test Status</h4></th>
                                        <th><h4>Test Name</h4></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {this.displayTableData(test)}
                                </tbody>
                            </table>
                        </div>
                    )
                }
            })
            return displayArray
        } else {
            console.log("something broke!!");
            return null
        }
    }

    displayTableData = (componentData) => {
        return componentData.testCases.map(comp => {
            let classtoApply = "";
            let symboltoDisplay = "";
            comp.testStatus === 'passed' ? classtoApply = 'text-success' : classtoApply = 'text-danger'
            comp.testStatus === 'passed' ? symboltoDisplay = <React.Fragment>&#10003;</React.Fragment> : symboltoDisplay = <React.Fragment>&#9747;</React.Fragment>

            return (
                <tr className={classtoApply}>
                    <td>{symboltoDisplay}</td>
                    <td>{comp.testName}</td>
                </tr>
            )
        })
    }

    fetchReport = () => {
        return axios.get("http://localhost:3080/evaluate")
            .then((response) => { return response.data })
            .catch(err => { this.setState({ testData: null }); return this.state.testData });
    }

    evaluate = () => {
        this.setState({ testData: null });
        return this.fetchReport().then((data) => {
            return this.setState({ testData: data });
        }).catch((err) => {
            return null
        })
    }

    render() {
        return (
            <div>
                {/* Message at the top after db setup */}
                {this.state.dbMessage ? (
                    <div className="col-md-5 offset-3">
                        <div className="alert alert-info alert-dismissible" id="alert">
                            <button type="button" className="close" data-dismiss="alert">&times;</button>
                            <strong>{this.state.dbMessage}</strong>
                        </div>
                    </div>
                ) : null}

                {/* Displays the button at the bottom right corner */}
                <div className="adminActions">
                    <input type="checkbox" name="adminToggle" className="adminToggle" />
                    <a className="adminButton" href="#!"><img src="assets/test.png" alt="admin button comes here" height="40px" width="55px" /></a>
                    <div className="adminButtons">
                        <a title="Setup DB" href="#!" onClick={this.setUpDb}><img src="assets/db.png" alt="setup button comes here" height="27px" width="30px" /></a>
                        <a title="Evaluate" href="#!" data-toggle="modal" data-target="#myModal" onClick={this.evaluate}><img src="assets/search.png"
                            alt="evaluator button comes here" height="27px" width="30px" /></a>
                    </div>
                </div>

                <div id="myModal" className="modal fade" role="dialog">
                    <div className="modal-dialog modal-lg">

                        <div className="modal-content">
                            <div className="modal-header bg">
                                <h4 className="modal-title">
                                    <img style={{ width: "50px", height: "50px" }} src={require("../assets/uilogo.png")} alt="ui team emblem" />
                                    Code analyser</h4>
                                <button type="button" className="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div className="modal-body">
                                <div className="row" id="load">
                                    <div className="col-md-12  text-center">
                                        {
                                            this.state.testData ? (
                                                <React.Fragment>
                                                    <ul className="nav nav-tabs">
                                                        {this.displayComponentTabs()}
                                                    </ul>
                                                    <div className="tab-content">
                                                        {this.displayTestReport()}
                                                    </div>
                                                </React.Fragment>
                                            ) : (
                                                    <React.Fragment>
                                                        <div className="form-group">
                                                            <img src="assets/gears.gif" alt="Loading..." />
                                                        </div>
                                                        <div className="form-group">
                                                            <h4 id="loading" className="text-center">Verifying code please wait .....</h4>
                                                        </div>
                                                    </React.Fragment>
                                                )
                                        }
                                    </div>
                                </div >
                            </div >
                        </div >

                    </div>
                </div>
            </div>

        )
    }
}


export default Evaluator;