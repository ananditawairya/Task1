import React, { Component } from "react";
import {Redirect} from 'react-router-dom'
import "../App.css";
/* Import the necessary modules Here */ 
import axios from 'axios'
import CreateBooking from './CreateBooking'

const url = "http://localhost:3080/fetchEvents";

/* DO NOT ADD REMOVE OR ALTER ANY STATE OF THE COMPONENT */
class Events extends Component {
    constructor(props) {
        super(props);
        this.state = {
            allEvents: [],
            errorMessage: "",
            selectedEvent: null
        };
    }

    componentDidMount(){
        console.log("Inside CDN");
        this.fetchEventDetails();
    }

    fetchEventDetails = () => {
        /*
        * reset the states allEvents to [] and errorMessage to ""
        * send an axios get request to the url "http://localhost:3080/fetchEvents" to fetch available events
        * In success case set allEvents state with response data, errorMessage with ""
        * In error case, check for error response, and accordingly set errorMessage state to
        * message of error response data 
        * OR 
        * "server error"
        * Invoke using appropriate life cycle method
        */
        console.log("Inside FetchDetails");
        
        axios.get(url).then(response => {
            console.log("--------Response-----------");
            
            console.log(response)
            this.setState({
              allEvents: response.data,
              errorMessage: ""
            });
          })
          .catch(error => {
            if (error.response) {
                console.log(error.response)
              this.setState({ errorMessage: error.response.data.message, allEvents:[] });
            } else {
              this.setState({ errorMessage:"server error", allEvents:[]});
            }
          });
    
    }

    book = (selectedEvent) => {
        /* Set the state selectedEvent with the parameter passed to the function i.e. selectedEvent */
        this.setState({selectedEvent:selectedEvent})
    }

    displayEvents = () => {
        /* 
        * Iterate over the allEvents state to create the cards.. 
        * The dummy code for each card is as given:-
        * <div className="col-4">
        *     <div className="card bg-light"> 
        *        <img className="card-img-top" src={"path of image source"} alt={"corresponding eventName"} />
        *           <div className="card-body">
        *              <h3 className="card-title">Name of the Event</h3>
        *                 <p>About the Event</p>
        *                 <p>Event Date comes here</p>
        *                 <p>Starting from &#x20b9; "Fare of the Event Booking"</p>
        *                 <button className="btn btn-custom btn-block">Book</button>
        *           </div>
        *      </div>
        * </div>
        */
       console.log(this.state.allEvents);
       
    let my_cards=this.state.allEvents.map((data,key)=>{
        return(
       <div className="col-4" key={key}>
           <div className="card bg-light"> 
                <img className="card-img-top" src={data.eventImage} alt={data.eventName} />
                   <div className="card-body">
                      <h3 className="card-title">{data.eventName}</h3>
                         <p>{data.aboutEvent}</p>
                         <p>{new Date(data.eventDate).toDateString()} </p>
                         <p>Starting from &#x20b9; "{data.fare}"</p>
                         <button className="btn btn-custom btn-block"  onClick={()=>this.book(data)}>Book</button>
                   </div>
              </div>
         </div>)
       })
       return my_cards
    }

    render() {
        /* 
        *  Load CreatBooking Component by passing selectedEvent data as event props
        *  When the user clicks on Book Button, use appropriate state 
        */
       console.log("Inside Render");
       
       
        return (
           
            <React.Fragment>
                <div className="container"><br /><br />
                    <div className="row">
                        {/* Invoke the required method Here to render the Events */}
                        
                        {(this.state.selectedEvent===null)?this.displayEvents():
                        <CreateBooking event={this.state.selectedEvent}/>}
                        

                    </div>
                </div>
            </React.Fragment>
        )
    }
}

export default Events;