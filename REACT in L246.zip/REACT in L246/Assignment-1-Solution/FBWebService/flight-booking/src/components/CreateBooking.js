import React, { Component } from "react";
import axios from "axios";

const url = "http://localhost:1050/bookFlight/";
const url1 = "http://localhost:1050/getFlightIds/";

class CreateBooking extends Component {
  constructor(props) {
    super(props);
    this.state = {
      form: {
        customerId: "",
        flightId: "",
        noOfTickets: ""
      },
      formErrorMessage: {
        customerId: "",
        flightId: "",
        noOfTickets: ""
      },
      formValid: {
        customerId: false,
        flightId: false,
        noOfTickets: false,
        buttonActive: false
      },
      flightIds: [],
      errorMessage: "",
      successMessage: ""
    };
  }

  submitBooking = () => {
    const { form } = this.state;
    this.setState({ errorMessage: "", successMessage: "" })
    axios.post(url, form)
      .then(response => {
        this.setState({ successMessage: response.data.message, errorMessage: "" });
      }).catch(error => {
        this.setState({ errorMessage: error.response.data.message, successMessage: "" });
      });
  };

  fetchFlightIds = () => {
    this.setState({ flightIds: [] });
    axios.get(url1)
      .then(response => this.setState({ flightIds: response.data, errorMessage: "" }))
      .catch(error => {
        if (error.status === 404) {
          this.setState({ flightIds: [], errorMessage: error.response.data.message })
        } else {
          this.setState({ flightIds: [], errorMessage: "Please start your Express server" })
        }
      })
  }

  componentDidMount() {
    this.fetchFlightIds();
  }

  handleSubmit = event => {
    event.preventDefault();
    this.submitBooking();
  };

  handleChange = event => {
    const target = event.target;
    const value = target.value;
    const name = target.name;
    const { form } = this.state;
    this.setState({ form: { ...form, [name]: value } });
    this.validateField(name, value);
  };

  validateField = (fieldName, value) => {
    let fieldValidationErrors = this.state.formErrorMessage;
    let formValid = this.state.formValid;

    switch (fieldName) {
      case "customerId":
        const customerIdRegex = /^[A-Z][0-9]{4}$/
        if (value === "") {
          fieldValidationErrors.customerId = "field required";
          formValid.customerId = false;
        } else if (!value.match(customerIdRegex)) {
          fieldValidationErrors.customerId = "Customer Id must start with an alphabet followed by 4 digits";
          formValid.customerId = false;
        } else {
          fieldValidationErrors.customerId = "";
          formValid.customerId = true;
        }
        break;
      case "noOfTickets":
        if (value === "") {
          fieldValidationErrors.noOfTickets = "field required";
          formValid.noOfTickets = false;
        } else if (value <= 0 || value > 10) {
          fieldValidationErrors.noOfTickets = "No of tickets should be greater than 0 and less than 10";
          formValid.noOfTickets = false;
        } else {
          fieldValidationErrors.noOfTickets = "";
          formValid.noOfTickets = true;
        }
        break;
      case "flightId":
        // const flightRegex = /^[A-Z]{3}-[0-9]{3}$/;
        if (value === "") {
          fieldValidationErrors.flightId = "Select a flight";
          formValid.flightId = false;
        } else {
          fieldValidationErrors.flightId = "";
          formValid.flightId = true;
        }
        break;
      default:
        break;
    }
    formValid.buttonActive =
      formValid.flightId &&
      formValid.customerId &&
      formValid.noOfTickets
    this.setState({ formErrorMessage: fieldValidationErrors, formValid: formValid, successMessage: "" })
  };

  render() {
    return (
      <div className="CreateBooking ">
        <div className="row">
          <div className="col-md-6 offset-md-3">
            <br />
            <div className="card">
              <div className="card-header bg-custom">
                <h3>Flight Booking Form</h3>
              </div>
              <div className="card-body">
                <form className="createBooking" onSubmit={this.handleSubmit}>
                  <div className="form-group">
                    <label htmlFor="customerId">Customer Id </label>
                    <input
                      type="text"
                      name="customerId"
                      id="customerId"
                      placeholder="e.g.- P1001"
                      value={this.state.form.customerId}
                      onChange={this.handleChange}
                      className="form-control"
                    />

                    <span name="customerIdError" className="text-danger">
                      {this.state.formErrorMessage.customerId}
                    </span>
                  </div>

                  <div className="form-group">
                    <label htmlFor="flightId">Flight ID</label>
                    <select
                      name="flightId"
                      id="flightId"
                      value={this.state.form.flightId}
                      onChange={this.handleChange}
                      className="form-control">
                      <option value="" key="">--Select Flight--</option>
                      {this.state.flightIds.length > 0 ?
                        this.state.flightIds.map(flightId => <option key={flightId} value={flightId}>{flightId}</option>)
                        : null}
                    </select>
                    <span name="flightIdError" className="text-danger">
                      {this.state.formErrorMessage.flightId}
                    </span>
                  </div>
                  <div className="form-group">
                    <label htmlFor="noOfTickets">Number of tickets</label>
                    <input
                      type="number"
                      name="noOfTickets"
                      id="noOfTickets"
                      placeholder="min-1 max-10"
                      value={this.state.form.noOfTickets}
                      onChange={this.handleChange}
                      className="form-control"
                    />
                    <span name="noOfTicketsError" className="text-danger">
                      {this.state.formErrorMessage.noOfTickets}
                    </span>
                  </div>

                  <button type="submit" className="btn btn-primary"
                    disabled={!this.state.formValid.buttonActive}>Book Flight</button>
                </form>
                <br />
                <span name="successMessage" className="text-success text-bold">
                  {this.state.successMessage}
                </span>
                <span name="errorMessage" className="text-danger text-bold">
                  {this.state.errorMessage}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CreateBooking;
