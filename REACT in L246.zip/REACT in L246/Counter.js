import React from 'react';

class Counter extends React.Component {
  counter = 0;

  state = {
    stateCounter:0
  };

  // componentDidMount = () => {
  //   this.setState({stateCounter:this.props.data});
  // }

  constructor() {
    super();
    console.log(this.counter);
  }

  increment=()=> {
    //alert('hi');
    // this.counter = this.counter + 1;
    // this.state.stateCounter = this.state.stateCounter +1;
    // console.log(this.state.stateCounter);
    console.log('Incrementing');

    this.setState({stateCounter: this.state.stateCounter+1}); // pass new state object

    // this.setState({stateCounter: this.state.stateCounter+1});
    // this.setState({stateCounter: this.state.stateCounter+1});
    console.log('Simple State Done->', this.state);
    

    this.setState((previousState)=>{
      console.log('Not so Simple State', this.state);
      console.log('previousState->',previousState);
      
      return {stateCounter: previousState.stateCounter+1};
    }); // to pass a CAllback;

    this.setState((previousState)=>{
      console.log('Not at all Simple State', this.state);
      console.log('previousState->',previousState);
      return {stateCounter: previousState.stateCounter+1};
    }); // to pass a CAllback;


    this.setState((pre)=>{
      console.log("FINALLLL STATE",pre);
    });


    console.log('end of increment!!!!!!', this.state);
  }

  render() {
    //.setState({stateCounter: this.state.stateCounter+1});
    console.log("Render called!!!!!!!");
    console.log("Recieved props form outside->",this.props);
    return (
      <React.Fragment>
        <h1>Hellooooo</h1>
        <h2>Counter: {this.state.stateCounter}</h2>
        <button onClick={this.increment}>Click</button>
      </React.Fragment>
    );
  }

}

export default Counter;