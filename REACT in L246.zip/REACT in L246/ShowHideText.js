import React from 'react'

export default class ShowHideText extends React.Component {

  state = {
    show: false,

    uInput: "",
    showError: true,
  };

  handleInput = (e) => {
    console.log('hi', e.target);
    const newVal = e.target.value;
    if(newVal.length>5) {
      this.setState(() => ({
        uInput: newVal,
        showError:false,
      }));
    } 
    else {
      this.setState(() => ({
        uInput: newVal,
        showError:true,
      }));
    }

  }

  render = () => {
    // const show = this.state.show;
    // const display = this.state.display;
    const { show, showError } = this.state;
    return (
      <React.Fragment>
        Enter some Text: <input
          value={this.state.uInput}
          onChange={this.handleInput}
        />
        <button
          onClick={() => { this.setState({ show: true }) }}
          className="btn btn-primary">
          Show
        </button>

        {show && <p>Hello React</p>}

        <button onClick={() => { this.setState({ show: false }) }}
          className="btn btn-primary">Hide</button>
        <hr />





        {showError && <p className="text-danger">Enter more than 5</p>}

      </React.Fragment>
    )
  }
}