var express = require('express');
var router = express.Router();

var data = [
  { id: 666, name:'Angad1', age:55 },
  { id: 667, name:'Angad2' ,age:45 },
  { id: 665, name:'Angad3', age:65 },
  { id: 664, name:'Angad4' ,age:25 }
];

/* GET home page. */
router.get('/getAll', function(req, res, next) {
  res.json(data)
});

router.post('/addEmp', function(req, res, next) {
  data.push(req.body)
  res.json(data)
});


router.put('/updateEmp', function(req, res, next) {
  data.push(req.body);
  res.json(data);
  data = data.filter((data)=>data.id!=req.body.id);
  data.push(req.body);
  res.json(data);

});

module.exports = router;
