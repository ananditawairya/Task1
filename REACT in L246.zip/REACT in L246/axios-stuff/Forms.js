import React from 'react';
import axios from 'axios';

const backEndPostURL = "http://localhost:3001/addEmp";

export default class HelloComp extends React.Component {

  state = {
    txtUsername: "",
    numAge: "",
    numPass: "",

    formErrors: {
      txtUsernameErr: "",
      numAgeErr: "",
      numPassErr: "",
    },

    formValidity: {
      txtUsernameErr: false,
      numAgeErr: false,
      numPassErr: false,
    },
    successMsg : '',
    errorMsg: '',
    formValid: false,
  };

  // handleInput = (bla) => {
  //   console.log(bla.target);
  //   const newInput = bla.target.value;
  //   this.setState(() => ({
  //     txtUsername: newInput,
  //   }));
  // }

  // handleAge = (e) => {
  //   const age = e.target.value;
  //   this.setState(() => ({
  //     numAge: age,
  //   }));
  // }

  // handlePass = (e) => {
  //   const pass = e.target.value;
  //   this.setState(() => ({
  //     numPass: pass,
  //   }));
  // }


  handleChange = (e) => {
    const value = e.target.value;
    const name = e.target.name;
    // const newState =  {};
    // newState[name]=newInput;
    // console.log(newState);
    // this.setState(()=>newState);
    this.setState(() => ({
      [name]: value,
    }));
    this.validateInputs(name, value);
  }



  validateInputs = (name, value) => {
    const newFormErrors = this.state.formErrors;
    const newFormValidity = this.state.formValidity;

    switch (name) {
      case 'txtUsername':
        if (value.length < 5) {
          newFormErrors.txtUsernameErr = "Some Err in Username";
          newFormValidity.txtUsernameErr = false;
        } else {
          newFormErrors.txtUsernameErr = "";
          newFormValidity.txtUsernameErr = true;
        }
        break;
      case 'numAge':
        if (-(-value) < 18) {
          newFormErrors.numAgeErr = "Some Err in numAge";
          newFormValidity.numAgeErr = false;
        } else {
          newFormErrors.numAgeErr = "";
          newFormValidity.numAgeErr = true;
        }
        break;

      case 'numPass':
        if (value.length < 5) {
          newFormErrors.numPassErr = "Some Err in numPass";
          newFormValidity.numPassErr = false;
        } else {
          newFormErrors.numPassErr = "";
          newFormValidity.numPassErr = true;
        }
        break;

      default:
        break;
    }

    // this.setState(() => ({
    //   formErrors: newFormErrors,
    //   formValidity: newFormValidity,
    // }));

    if (newFormValidity.txtUsernameErr &&
      newFormValidity.numAgeErr &&
      newFormValidity.numPassErr) {
      this.setState(() => ({ 
        formValid: true, 
        formErrors: newFormErrors,
        formValidity: newFormValidity, 
      }));
    } else {
      this.setState(() => ({ 
        formValid: false, 
        formErrors: newFormErrors,
        formValidity: newFormValidity, 
      }));
    }

  }

  handleSubmit = (e) => {
    e.preventDefault();
    alert('Submitting');
    const {txtUsername, numAge, numPass} = this.state;
    let formData = {
      name: txtUsername,
      age: numAge,
      id: numPass,
    };
    alert(JSON.stringify(formData));

    axios.post(backEndPostURL,formData)
      .then((success)=>{
        this.setState(()=>({
          // successMsg : success.message
          successMsg : "DOne successfully...!!!!",
          errorMsg: '',
        }));
      })
      .catch((err)=>{
        this.setState(()=>({
          // successMsg : success.message
          errorMsg : "Something went Wrong!",
          successMsg: '',
        }));
      });


  }


  render() {
    const { formErrors, formValid, successMsg, errorMsg } = this.state;

    return (
      <React.Fragment>
        <div>
          <form onSubmit={this.handleSubmit}>
            {JSON.stringify(this.state)}
            <br />
            Enter Name: <input type="text"
              name="txtUsername"
              value={this.state.txtUsername}
              onChange={this.handleChange} />
            <br />
            {(formErrors.txtUsernameErr !== "") &&
              <p className="text-danger">{formErrors.txtUsernameErr}</p>
            }

            Enter Age: <input type="number"
              name="numAge"
              value={this.state.numAge}
              onChange={this.handleChange} />
            <br />

            {(formErrors.numAgeErr !== "") &&
              <p className="text-danger">{formErrors.numAgeErr}</p>
            }

            Enter Pass: <input type="password"
              name="numPass"
              value={this.state.numPass}
              onChange={this.handleChange} />
            <br />

            {(formErrors.numPassErr !== "") &&
              <p className="text-danger">{formErrors.numPassErr}</p>
            }
            <button className="btn btn-primary" disabled={!formValid} type="submit">Submit</button>
          
          </form>

          <div>
            <p className="text-success">{successMsg}</p>
            <p className="text-danger">{errorMsg}</p>
          </div>


        </div>

      </React.Fragment>
    );
  }
}
