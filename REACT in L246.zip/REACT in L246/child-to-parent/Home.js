import React from 'react';
import HomeChild from './HomeChild';


export default class Home extends React.Component {

  state = {
    dataBack:'',
  };

  handleBackClick = (param1, param2)=> {
    console.log("Home's click handler");
    console.log(param1, param2);
    this.setState(()=>({
      dataBack: param2,
    }));
  }
  render() {
    
    return (
      <React.Fragment>
        <h1>HOME</h1>
        {this.state.dataBack}
        <hr />
        <HomeChild handleParentsClick={this.handleBackClick}/>
      </React.Fragment>
    );
  }
}