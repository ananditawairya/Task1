import React from 'react';

export default class HomeChild extends React.Component {


  handleClick = (e)=> {
    console.log("HomeChild's click handler");
    const {handleParentsClick} = this.props;
    handleParentsClick(e.target, 666);
  }

  render() {
    return (
      <React.Fragment>
        <h2>Home's Child</h2>
        <button onClick={this.handleClick} className="btn btn-primary">
          Click to send data Back!!!
        </button>
      </React.Fragment>
    )
  }
}