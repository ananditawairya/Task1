import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap/dist/css/bootstrap.min.css';


let data = [
  { id: 666, name: 'John', age: 23 },
  { id: 666, name: 'John', age: 23 },
  { id: 666, name: 'John', age: 23 },
  { id: 666, name: 'John', age: 23 },
  { id: 666, name: 'John', age: 23 },
]
function showTable() {
  return (
    <table className="table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Age</th>
        </tr>
      </thead>
      <tbody>
        {/* {
          (data && data.length > 0) === true ? 
                                        data.map((ele, key) => <tr key={key}>
                                        <td>{ele.id}</td>
                                        <td>{ele.name}</td>
                                        <td>{ele.age}</td>
                                      </tr>) 
        : null
      } */}

        {(data && data.length > 0) && (
          data.map((ele, key) => <tr key={key}>
            <td>{ele.id}</td>
            <td>{ele.name}</td>
            <td>{ele.age}</td>
          </tr>
          )
        )}



        {/* {data.map((ele, key) => <tr key={key}>
          <td>{ele.id}</td>
          <td>{ele.name}</td>
          <td>{ele.age}</td>
        </tr>
        )} */}
      </tbody>
    </table>
  );
}

function showCardS() {
  // will show all cards properly!!!
  // Row
  return (
    <React.Fragment>
      <div className="row" >
        {data.map((aCardData,key)=>{
          return aCard(aCardData);
        })}
      </div>
    </React.Fragment>
  );
}

function aCard(cardata) {
  return (
    <div className="card bg-primary col-3" >
      <p>{cardata.id}</p>
      <p>{cardata.name}</p>
      <p>{cardata.age}</p>
    </div>
  )
}



function showPage() {
  return (
    <React.Fragment>
      <h1>Navbar</h1>
      <div className="container-fluid">
        <h2>Table of data</h2>
        {showTable()}
        <br/>
        <h3>Same data as cards!</h3>
        {showCardS()}
      </div>
    </React.Fragment>
  )
}

ReactDOM.render(showPage(), document.getElementById('root2'));