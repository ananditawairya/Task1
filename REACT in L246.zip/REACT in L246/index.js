import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
//import App from './App';
import * as serviceWorker from './serviceWorker';

let flag = true;
console.log(flag);



const heading = <h1>Hello WOrld</h1>;
const boolT = true;
const stringData = "Hello World";
const numData = 666;
const show = <div>{boolT} {stringData} {numData}</div>;
const today = new Date();
const objData = { id: 666, name: "John" };
const arrData = [1, 2, 3, 4];
const mixedArr = [<h1>Hello</h1>, <h2>666</h2>, <br />, "Car2"];

function showData() {
  // const jsx = [<ul>
  //               <li>{heading}</li>
  //               <li>{objData.id}</li>
  //             </ul>,
  //             <h2>BLLLL</h2>
  //           ];
  // return jsx;
  const borderType = "2";
  return (
    <React.Fragment>
      <ul>
        <li>{heading}</li>
        <li>{objData.name}</li>
      </ul>
      <table className="table" border={borderType} >
        <thead>
          <tr>
            <th>Heading 1</th>
            <th>Heading 2</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Data 1</td>
            <td>Data 2</td>
          </tr>
        </tbody>
      </table>

      <h2>BLLLL</h2>
    </React.Fragment>
  );
}


function showJSX() {
  const dateStr = new Date().toDateString();
  let button;

  if (flag) {
    button = <button>Button to show</button>
  }
  return (
    <React.Fragment>
      <h1>Heloo WOrld</h1>
      <h1>{dateStr}</h1>
      {showData()}
      {showButton()}
      {button}
      {flag === true ? (
        <button onClick={() => { clickHandler() }}>Hello</button>
      ) : (
          <button>Bye</button>
        )}
    </React.Fragment>
  );
}

function showButton() {
  if (new Date().getHours() < 12) {
    return (
      <React.Fragment>
        <button onClick={() => { alert('My alert!!!!') }} >Morning</button>
        <button onClick={(e) => { clickHandler(e) }} >Morning 2</button>
        {/* <button onClick={clickHandler} >Morning 3</button> */}
      </React.Fragment>
    );
  } else {
    return <button>Afternoon</button>;
  }
}

function clickHandler(data) {
  console.log(data);
  alert('Hello forom click ' + data);

  flag = false;
  console.log(false);


}

// function clock() {
//   return (<h1>{new Date().toTimeString()}</h1>);
// }

// setInterval(()=>{
//   ReactDOM.render(clock(), document.getElementById('root2'));
// }, 1000);




let dataArr;
let datawithFOrEachLI = [];
// [ <li>666</li>, <li>Car</li>, ]

dataArr.forEach((element, index) => {
  console.log("000", element);
  datawithFOrEachLI.push(<li key={index}>{element}</li>);
});
console.log(datawithFOrEachLI);

const listDataWithFOrEach = (
  <React.Fragment>
    <ul>
      {datawithFOrEachLI}
    </ul>
  </React.Fragment>
);

const finalData = (
  <React.Fragment>
    <ul>
      {dataArr.map((ele, key) => {
        return <li key={key}>666</li>;
        // return <li key={key}>{ele}</li>
      })}
    </ul>
  </React.Fragment>
)








ReactDOM.render(finalData, document.getElementById('root2'));






































// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
