import React from 'react';

export default function ACard(props) {
  const cardata = props.cardata;
  //console.log('Cards',props);
  
  return (
    <div className="card bg-primary col-3" >
      <p>{cardata.id}</p>
      <p>{cardata.name}</p>
      <p>{cardata.age}</p>
    </div>
  )
}