import React from 'react';
//import logo from './logo.svg';
import './App.css';
import Table from './Table';
import Navbar from './Navbar';
import Cards from './Cards';
import Counter from './Counter';
import LifeCycle from './LifeCycle';

const data = [
  { id: 666, name: 'John', age: 23 },
  { id: 666, name: 'John', age: 23 },
  { id: 666, name: 'John', age: 23 },
  { id: 666, name: 'John', age: 23 },
  { id: 666, name: 'John', age: 23 },
]

function App() {
  return (
    <React.Fragment>
      <Navbar/>
      <LifeCycle/>
      <hr/>
      <Counter data={666}/>
      <hr/>

      <div className="container-fluid">
        <h2>Table of data</h2>
        {/* {showTable(data)} */}
        <Table dataToSend={data} dataBla={666} />
        <br/>
        <h3>Same data as cards!</h3>
        {/* {showCardS()} */}
        <Cards allCards={data}/>
      </div>
    </React.Fragment>

  );
}

export default App;
