import React from 'react';
import ACard from './ACard';

export default function Cards(props) {
  const data = props.allCards;
  return (
    <React.Fragment>
      <div className="row" >
        {data.map((aCardData,key)=>{
          // return aCard(aCardData);
          return (
            <ACard key={key} myKey={key} cardata={aCardData}/>
          );
        })}
      </div>
    </React.Fragment>
  );
}
