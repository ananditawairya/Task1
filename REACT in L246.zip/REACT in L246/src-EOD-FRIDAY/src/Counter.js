import React from 'react';

class Counter extends React.Component {
  counter = 0;

  state = {
    bla:777,
    stateCounter: 0,
    myObjAttr : {id:888, age:777},
  };

  // componentDidMount = () => {
  //   this.setState({stateCounter:this.props.data});
  // }

  componentDidMount = () =>{
    //console.log("componentDidMount");
    this.setState(()=>{
      //console.log("componentDidMount state change");
      return { 
        stateCounter: this.props.data,
      };
    });
  }




  // constructor() {
  //   super();
  //   console.log("constructor",this.counter, this.props.data);
  //   //this.setState({stateCounter: this.props.data})
  // }

  increment=()=> {
  
    //console.log('Incrementing');

    this.setState({stateCounter: this.state.stateCounter+1}); // pass new state object

    //console.log('Simple State Done->', this.state);
    

    this.setState((previousState)=>{
      // console.log('Not so Simple State', this.state);
      // console.log('previousState->',previousState);
      
      return {stateCounter: previousState.stateCounter+1};
    }); // to pass a CAllback;

    this.setState((previousState)=>{
      // console.log('Not at all Simple State', this.state);
      // console.log('previousState->',previousState);
      return {stateCounter: previousState.stateCounter+1};
    }); // to pass a CAllback;


    // this.setState((pre)=>{
    //   console.log("FINALLLL STATE",pre);
    // });


    //console.log('end of increment!!!!!!', this.state);
  }

  addId = ()  => {
    this.setState(()=>{
      return {
        myObjAttr: { 
          id: this.state.myObjAttr.id+1,
          age: this.state.myObjAttr.age,
        }
      };
      // return { // NOT DO THIS!!!
      //   id: this.state.myObjAttr.id+1
      // }
    });
  }

  render() {
    //.setState({stateCounter: this.state.stateCounter+1});
    //console.log("Render called!!!!!!!");
    //console.log("Recieved props form outside->",this.props);
    return (
      <React.Fragment>
        <h1>Hellooooo</h1>
        <h3>Counter: {this.state.stateCounter}</h3>
        <h3>Bla: {this.state.bla}</h3>
        <h3>myObjAttr: {JSON.stringify(this.state.myObjAttr)}</h3>
        <button onClick={this.increment}>Click</button>
        <button onClick={this.addId}>Add to id</button>
      </React.Fragment>
    );
  }

}

export default Counter;