import React from 'react';

export default class LifeCycle extends React.Component {
  render() {
    console.log("render");
    return <h1 onClick={()=>{this.setState({})}}>LifeCycle Demo</h1>
  }
  constructor() {
    super();
    console.log("constructor");
  }

  componentWillMount=()=> {
    console.log('componentWillMount, WARNING, not use this anymore');
  }

  componentDidMount=()=> {
    console.log('componentDidMount, Mounted in DOM');
  }

  componentWillUpdate = ()=> {
    console.log('componentWillUpdate !!!!');
  }

  componentDidUpdate=()=> {
    console.log('componentDidUpdate !!!!');
  }




}