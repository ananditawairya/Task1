import React from  'react';
export default function Navbar() {
  return (
    <React.Fragment>
      <h1>Navbar</h1>
    </React.Fragment>
  );
}