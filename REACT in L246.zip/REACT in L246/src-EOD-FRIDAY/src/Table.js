import React from 'react';

function Table(props) {
  //console.log(props);
  //console.log(props.dataBla);
  const data = props.dataToSend;
  return (
    <table className="table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Age</th>
        </tr>
      </thead>
      <tbody>
        {/* {
          (data && data.length > 0) === true ? 
                                        data.map((ele, key) => <tr key={key}>
                                        <td>{ele.id}</td>
                                        <td>{ele.name}</td>
                                        <td>{ele.age}</td>
                                      </tr>) 
        : null
      } */}

        {(data && data.length > 0) && (
          data.map((ele, key) => <tr key={key}>
            <td>{ele.id}</td>
            <td>{ele.name}</td>
            <td>{ele.age}</td>
          </tr>
          )
        )}



        {/* {data.map((ele, key) => <tr key={key}>
          <td>{ele.id}</td>
          <td>{ele.name}</td>
          <td>{ele.age}</td>
        </tr>
        )} */}
      </tbody>
    </table>
  );
}

export default Table;