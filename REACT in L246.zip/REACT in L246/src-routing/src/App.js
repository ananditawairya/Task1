import React, {Component} from 'react';
//import logo from './logo.svg';
import './App.css';

import Home from './components/Home';
import News from './components/News';

import {BrowserRouter as Router, 
  Link, Route , Redirect, Switch} from 'react-router-dom';



class App extends Component {

  render() {

    return (
        <Router>
        <nav>
          <Link to={"/"}>HOME </Link>
          <Link to={"/news"}>News</Link>
          <Link to={"/contact"}>CONTACT</Link>
          <Link to={"/news/"+666}>News with data</Link>
        </nav>
        <hr/>
        <hr/>
        <hr/>

        <Home/>

        <Switch>
          <Route exact path="/" component={Home}/>
          <Route exact path="/news" component={News}/>
          <Route exact path="/news/:BLA" component={News}/>
          {/* <Route exact path="/contact" render={()=>{
            return (
            <Home/>
            )
          }} />
          <Route exact path="/news" render={()=>{
            return <Redirect to="/contact"/>
          }}  />  */}

          <Route exact path="/news" component={News}/>
          <Route exact path="/contact" render={_=><h1>CONTACT!!</h1>}/>

          <Route exact path="/*" render={_=><h1>ERROR!!</h1>}/>

        </Switch>


        </Router>


    );
  }

}

export default App;
