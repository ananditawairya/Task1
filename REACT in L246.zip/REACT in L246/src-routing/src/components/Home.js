import React from  'react';
export default function Home() {
  return (
    <React.Fragment>
      <h1>HOME</h1>
      <hr/>
    </React.Fragment>
  );
}