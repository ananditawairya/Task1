import React from  'react';
export default function News(props) {
  return (
    <React.Fragment>
      {JSON.stringify(props.match.params.BLA)}
      <h1>NEWS...</h1>
      <hr/>
    </React.Fragment>
  );
}