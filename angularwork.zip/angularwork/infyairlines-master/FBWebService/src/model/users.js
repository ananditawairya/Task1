const dbModel = require('../utilities/connection');

var flightBookingDb = {}

flightBookingDb.generateId = () => {
    return dbModel.getBookingCollection().then((model) => {
        return model.distinct("bookingId").then((ids) => {
            var bId = Math.max(...ids);
            return bId + 1;
        })
    })
}

flightBookingDb.checkAvailability = function (flightId) {
    return dbModel.getFlightCollection().then(function (model) {
        return model.findOne({ flightId: flightId }).then(function (flightRecord) {
            if (!flightRecord || flightRecord.length == 0) return null;
            else return flightRecord;
        })
    })
}

flightBookingDb.bookFlight = function (flightBooking) {
    return dbModel.getBookingCollection().then(function (model) {
        return flightBookingDb.generateId().then(function (fid) {
            flightBooking.bookingId = fid;
            return model.create(flightBooking).then(function (flight) {
                return dbModel.getFlightCollection().then(function (model1) {
                    return model1.findOne({ flightId: flightBooking.flightId }).then(function (flightRecord) {
                        return model1.updateOne({ flightId: flightBooking.flightId }, { $set: { "availableSeats": flightRecord.availableSeats - flightBooking.noOfTickets } })
                    }).then(function (saved) {
                        if (saved.nModified < 1) throw new Error("Seats could not be updated");
                        else return fid;
                    })
                })
            })
        })
    })
}

flightBookingDb.getAllBookings = () => {
    return dbModel.getBookingCollection().then(model => {
        return model.find().then(bookings => {
            if (bookings.length > 0) return bookings;
            else return null;
        })
    })
}

flightBookingDb.deleteBooking = (id) => {
    return dbModel.getBookingCollection().then(model => {
        return model.deleteOne({ bookingId: id }).then(deleted => {
            if (deleted.n > 0) return id;
            else return null;
        })
    })
}

module.exports = flightBookingDb;