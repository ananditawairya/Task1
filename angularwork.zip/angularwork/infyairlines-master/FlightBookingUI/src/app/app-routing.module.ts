import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookFlightComponent } from "./book-flight/book-flight.component";
import { ViewDetailsComponent } from './view-details/view-details.component';


export const routes: Routes = [
  //Add logic for routes
  {path:'book',component:BookFlightComponent},
  {path:'view',component:ViewDetailsComponent},
  { path: '**', redirectTo: '/book', pathMatch: 'full' },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
