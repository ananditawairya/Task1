import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormControl, FormGroup } from '@angular/forms';
import { BookFlightService } from "./book-flight.service";
import { log } from 'util';

@Component({
  selector: 'app-book-flight',
  templateUrl: './book-flight.component.html',
  styleUrls: ['./book-flight.component.css'],
  providers: [BookFlightService]
})
export class BookFlightComponent implements OnInit {

  errorMessage: String;
  successMessage: String;
  
//add neccessary dependencies
  constructor(public formBuilder:FormBuilder,public booking:BookFlightService) { }

  bookingForm:FormGroup;

  

  ngOnInit() {
    this.bookingForm=this.formBuilder.group({
      passengerName:['',[Validators.required,Validators.pattern('[A-Za-z][A-Za-z ]*')]],
      noOfTickets:['',[Validators.required,Validators.min(1)]],
      flightId:['',[Validators.required,validateFlight]],
    })
  }

  book() {
    //your code goes here
   this.booking.bookFlight(this.bookingForm.value).subscribe(
     (success)=>{this.successMessage=success.message,this.errorMessage=""},
     (error)=>{this.errorMessage=error.error.message,this.successMessage=""}
   )


  }
}

function validateFlight(c: FormControl) {
  //your code goes here
  let flight=c.value;
  let regex=/^(IND-)[1-9][0-9]{2}$/

  return regex.test(flight) ? null : {
    flightError: {
        message: "Enter valid flightID"
    }
};

}


