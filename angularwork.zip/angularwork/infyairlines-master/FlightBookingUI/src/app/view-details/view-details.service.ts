import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FlightBooking } from '../shared/FlightBooking';
import { Observable } from 'rxjs';

@Injectable()
export class ViewDetailsService {

  url1="http://localhost:1050/getAllBookings"
  
 //add neccessary dependencies
  constructor(private http:HttpClient) {
   
  }

  view(): Observable<FlightBooking[]> {
    return this.http.get<FlightBooking[]>(this.url1)
  }

  delete(bookingId): Observable<any> {
    return this.http.delete<Observable<any>>("http://localhost:1050/delete/"+bookingId)
  }
}
