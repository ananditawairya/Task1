import React, { Component } from "react";
import axios from "axios";
import {Redirect} from "react-router-dom";

const url = "http://localhost:1050/getAllBookings/";
const url1 = "http://localhost:1050/deleteBooking/";

class GetBooking extends Component {
  constructor(props) {
    super(props);
    this.state = {
      bookingData: "",
      bookingId: "",
      updateStatus: false,
      errorMessage: "",
      successMessage: ""
    };
  }

  componentDidMount = ()=>{
    this.fetchBooking();
  }

  updateBooking = (bid) => {
    /* update the updateStatus and bookingId state with appropriate values */
    this.setState({bookingId:bid})
    this.setState({updateStatus:true})
 
  }

  fetchBooking = () => {
    /* 
      Send an AXIOS GET request to the url http://localhost:1050/getAllBookings/ to fetch all the bookings 
      and handle the success and error cases appropriately 
    */
   axios
      .get(url)
      .then(response => {
        console.log("get", response)
        this.setState({
         bookingData: response.data,
          errorMessage: ""
        });
      })
      .catch(error => {
        console.log("get", error.response)
          this.setState({ errorMessage: error.response.data.message, bookingData:"" });
      
      });

  }

  deleteBooking = (id) => {
    /*
      Send an AXIOS DELETE request to the url http://localhost:1050/deleteBooking/ to delete the selected booking
      and handle the success and error cases appropriately 
    */
   axios
      .delete(url1+id)
      .then(response => {
        console.log("del", response)
        this.setState({
         successMessage: response.data,
          errorMessage: ""
        });
        this.fetchBooking();
      })
      .catch(error => {
        if (error.status===404) {
          this.setState({ errorMessage: error.response.data.message, bookingData:"" });
        } else {
          this.setState({ errorMessage: "Please start your Express server", bookingData:"" });
        }
      });
  }

  render() {
    const { bookingData} = this.state;
    
    return (
      <div className="GetBooking">
        <div className="row">
          <div className="col-md-6 offset-md-3">
            <br />
            <div className="card">
              <div className="card-header bg-custom">
                <h3 align="center">Booking Details</h3>
              </div>
              <div className="card-body">
                {/* code here to get the view as shown in QP for GetBooking component */}
                {/* Display booking data in tabular form */}
                {/* Display error message if the server is not running */}
                {/* code appropriately to redirect on click of update button */}
                {bookingData=== "" && <span className="text-danger">Could not fetch booking data</span>}
                {this.state.errorMessage==="" && bookingData!=="" &&
                (
                  <div>
                    <table className="table table-bordered">
                      <thead>
                        <tr>
                          <th>Customer Id</th>
                          <th>Booking Id</th>
                          <th>Total Tickets</th>
                          <th>Total Cost</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                      {bookingData.map((element,key)=>{return(
                      <tr key={key}>
                        <td>{element.customerId}</td>
                        <td>{element.bookingId}</td>
                        <td>{element.noOfTickets}</td>
                        <td>{element.bookingCost}</td>
                        <td>
                          
                           
                              <button className="btn btn-success" onClick={()=>{this.updateBooking(element.bookingId)}}>Update</button>
                              {this.state.updateStatus && <Redirect to={"/updateBooking/"+this.state.bookingId+"/"}/>}
                              {console.log(element.bookingId)}
                         
                              <button className="btn btn-danger" onClick={()=>{this.deleteBooking(element.bookingId)}}>Cancel</button>
                           
                       
                        </td>
                      </tr>
                      )})}
                      </tbody>
                    </table>
                  </div>
                ) 
                }

              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default GetBooking;
