import React, { Component } from "react";
import axios from "axios";

const url = "http://localhost:1050/updatebooking/";

class UpdateBooking extends Component {
    constructor(props) {
        super(props);
        this.state = {
            form: {
                bookingId: "",
                noOfTickets: ""
            },
            formErrorMessage: {
                bookingId: "",
                noOfTickets: ""
            },
            formValid: {
                bookingId: true,
                noOfTickets: false,
                buttonActive: false
            },
            successMessage: "",
            errorMessage: "",
            id: this.props.match.params.bookingId
        };
    }


    updateBooking = () => {
        /* 
          Make a axios PUT request to http://localhost:1050/updatebooking/ to update the number of tickets 
          for the selected bookingId and handle the success and error cases appropriately 
        */
       let object={
           noOfTickets:this.state.form.noOfTickets
       }
       console.log(this.state.id,object)
       axios
      .put(url+this.state.id,object)
      .then(response => {
        
        console.log("put", response)
        this.setState({
          successMessage: response.data.message,
          errorMessage: ""
        });
      })
      .catch(error => {
        console.log("put", error.response)
          this.setState({ errorMessage: error.response.data.message, successMessage:"" });
       
      });
    }

    handleSubmit = (event) => {
        /* prevent page reload and invoke updateBooking() method */
        event.preventDefault();
        this.updateBooking();
    }

    handleChange = (event) => {
        /* 
          invoke whenever any change happens any of the input fields
          and update form state with the value. Also, Inoke validateField() method to validate the entered value
        */
    let name = event.target.name;
    let value = event.target.value;
    let newState = this.state.form;
    newState[name] = value
    this.setState({ form: newState })
    this.validateField(name, value)
    }

    validateField = (fieldName, value) => {
        /* Perform Validations and assign error messages, Also, set the value of buttonActive after validation of the field */
        let formValidCopy = this.state.formValid;
        let formErrorMessageCopy = this.state.formErrorMessage;
        switch(fieldName){
        case "noOfTickets":
        if (value === "" || value === null) {
          formValidCopy.noOfTickets = false;
          formErrorMessageCopy.noOfTickets = "field required"
        }
        else if (!(Number(value) > 0 && Number(value) < 10)) {
          formValidCopy.noOfTickets = false;
          formErrorMessageCopy.noOfTickets = "No of tickets should be greater than 0 and less than 10"
        }
        else {
          formValidCopy.noOfTickets = true;
          formErrorMessageCopy.noOfTickets = ""
        }
        break;
      default:
        break;

    }
    formValidCopy.buttonActive = formValidCopy.noOfTickets;
    this.setState({ formValid: formValidCopy })
    this.setState({ formErrorMessage: formErrorMessageCopy })
    }
    

    render() {
        return (
            <React.Fragment>
                <div className="UpdateBooking">
                    <div className="row">
                        <div className="col-md-6 offset-md-3">
                            <br />
                            <div className="card">
                                <div className="card-header bg-custom">
                                    <h4>Update Flight Booking for id: {this.state.id}</h4>
                                </div>
                                <div className="card-body">
                                    {/* code appropriately to render the form as shown in QP */}
                                    {/* display the success and error messages appropriately */}
                                    <form onSubmit={this.handleSubmit}>
                  <div className="form-group">
                    <label> bookingId </label>
                    <input type="number" className="form-control"
                      value={this.state.id} name="bookingId" readOnly={true} />
                  </div>
                  <span className="text-danger" name="bookingIdError">{this.state.formErrorMessage.bookingId}</span>
                 
                  <div className="form-group">
                    <label> Number of tickets</label>
                    <input type="number" className="form-control"
                      placeholder="min-1 max-10" name="noOfTickets" onChange={this.handleChange} />
                  </div>
                  <span className="text-danger" name="noOfTicketsError">{this.state.formErrorMessage.noOfTickets}</span><br/>
                  <button type="submit" className="btn btn-primary" disabled={!this.state.formValid.buttonActive}>Update Booking</button><br/>
                  <span className="text-success" name="SuccessMessage">{this.state.successMessage}</span>
                  <span className="text-danger"  name="ErrorMessage">{this.state.errorMessage}</span>
                </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default UpdateBooking;