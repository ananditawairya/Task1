const express = require('express');
const routing = express.Router();
const create = require('../model/dbsetup');
const flightBookingServ = require('../service/users');
const FlightBooking = require('../model/flightbooking');
const parser = require("../parser").reportGenerator

routing.get("/test", (req, res, next) => {
    parser().then((data) => {
        console.log("Verification Completed", data)
        res.send(data)
    }).catch((err) => {
        console.log(err.message);
        next(err)
    })
})


// setup db
routing.get('/setupDb', (req, res, next) => {
    create.setupDb().then((data) => {
        res.send({ message: data })
    }).catch((err) => {
        next(err)
    })
})

//Insert and update
routing.post('/bookFlight', (req, res, next) => {
    const flightBooking = new FlightBooking(req.body);
    flightBookingServ.bookFlight(flightBooking).then((bookingId) => {
        res.json({ "message": "Flight booking is successful with booking Id :" + bookingId });
    }).catch((err) => next(err)
    )
})

routing.get('/getAllBookings', (req, res, next) => {
    flightBookingServ.getAllBookings().then(bookings => {
        res.json(bookings)
    }).catch((err) => next(err))
})

routing.delete('/delete/:id', (req, res, next) => {
    const id = parseInt(req.params.id)
    flightBookingServ.deleteBooking(id).then(deletedId => {
        res.json({ "message": "Successfully deleted Id: " + deletedId })
    }).catch((err) => next(err))
})


module.exports = routing;
