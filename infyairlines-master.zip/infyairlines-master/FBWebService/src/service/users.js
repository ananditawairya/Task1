const db = require('../model/users');
const validator = require('../utilities/validator');

const fBookingService = {}

fBookingService.bookFlight = (flightBooking) => {
    validator.validateFlightId(flightBooking.flightId);
    return db.checkAvailability(flightBooking.flightId).then((flight) => {
        if (flight == null || flight.status == 'Cancelled') {
            throw new Error("Flight unavailable or cancelled");
        }
        else if (flight.availableSeats < flightBooking.noOfTickets) {
            throw new Error("Requested number of seats unavailable");
        }
        else {
            flightBooking.totalAmount = flightBooking.noOfTickets * flight.fare;
            promise = db.bookFlight(flightBooking);
            return promise;
        }
    }).then((bookingId) => {
        return bookingId;
    })
}

fBookingService.getAllBookings = () => {
    return db.getAllBookings().then(bookings => {
        if (bookings == null) {
            let err = new Error("No Bookings Done in any flight!!");
            err.status = 404;
            throw err;
        } else return bookings;
    })
}

fBookingService.deleteBooking = (id) => {
    return db.deleteBooking(id).then(deletedId => {
        if (deletedId == null) {
            let err = new Error("Booking could not be deleted!!");
            err.status = 500;
            throw err;
        }else return deletedId;
    })
}

module.exports = fBookingService;