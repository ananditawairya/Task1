import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookFlightComponent } from "./book-flight/book-flight.component";
import { ViewDetailsComponent } from './view-details/view-details.component';


export const routes: Routes = [
  //Add logic for routes
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
