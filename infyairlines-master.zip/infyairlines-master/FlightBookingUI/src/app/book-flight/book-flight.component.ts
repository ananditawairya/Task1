import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormControl, FormGroup } from '@angular/forms';
import { BookFlightService } from "./book-flight.service";

@Component({
  selector: 'app-book-flight',
  templateUrl: './book-flight.component.html',
  styleUrls: ['./book-flight.component.css'],
  providers: [BookFlightService]
})
export class BookFlightComponent implements OnInit {

  errorMessage: String;
  successMessage: String;
//add neccessary dependencies
  constructor() { }

  bookingForm:FormGroup

  ngOnInit() {
  }

  book() {
    //your code goes here
  }
}

function validateFlight(c: FormControl) {
  //your code goes here
}


