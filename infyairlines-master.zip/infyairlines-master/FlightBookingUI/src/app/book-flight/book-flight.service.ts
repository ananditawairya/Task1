import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';



@Injectable()
export class BookFlightService {

  url = "http://localhost:1050/bookFlight"
  //add neccessary dependencies
  constructor() { }
  //your code goes here
  bookFlight(data: any): Observable<any> {
    return
  }
}
