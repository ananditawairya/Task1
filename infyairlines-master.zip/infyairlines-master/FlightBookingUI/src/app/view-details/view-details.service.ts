import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FlightBooking } from '../shared/FlightBooking';
import { Observable } from 'rxjs';

@Injectable()
export class ViewDetailsService {

 //add neccessary dependencies
  constructor() {
   
  }

  view(): Observable<FlightBooking[]> {
    return 
  }

  delete(bookingId): Observable<any> {
    return 
  }
}
