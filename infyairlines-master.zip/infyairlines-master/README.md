# InfyAirlines

Single Page Application using Angular with bootstrap 4.0