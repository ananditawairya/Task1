import React, { Component } from "react";
import { Link,Switch,Route,Redirect } from "react-router-dom";
import AllocateSolar from './components/AllocateSolar'
import GetDistributors from './components/GetDistributors'
/* Import the required modules/dependencies here */  

/* DO NOT REMOVE THIS IMPORT STATEMENT */
import Evaluator from './components/evaluator';
import "./App.css";
class App extends Component {
  render() {
    return (
      <div>
        { /* DO NOT REMOVE THIS COMPONENT TAG */}
        <Evaluator></Evaluator>

        <nav className="navbar navbar-expand-lg navbar-light  bg-custom">
          <span className="navbar-brand">IBA Retails</span>
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link" to="/allocateSolar"> Allocate Solar </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/getDistributors"> View Distributors </Link>
            </li>
          </ul>
        </nav>
        {/* your routing code goes here */}
        <Switch>
        <Switch>
          <Route exact path="/allocateSolar" component={AllocateSolar} />
          <Route exact path="/getDistributors" component={GetDistributors} />    
          <Route exact path="/**" render={() => (<Redirect to="/allocateSolar" />)}/>
        </Switch>
        </Switch>
      </div>
    );
  }
}

export default App;
