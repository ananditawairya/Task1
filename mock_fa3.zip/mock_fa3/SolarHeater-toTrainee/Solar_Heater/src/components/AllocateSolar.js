import React, { Component } from "react";
import axios from "axios";
import "../App";

const url = "http://localhost:2040/allocate/";

class AllocateSolar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formValue: {
        distributorName: "",
        purchaseDate: "",
        installationDate: "",
        customerName: "",
        customerLocation: ""
      },
      formErrorMessage: {
        distributorName: "",
        purchaseDate: "",
        installationDate: "",
        customerName: "",
        customerLocation: ""
      },
      formValid: {
        distributorName: false,
        purchaseDate: false,
        installationDate: false,
        customerName: false,
        customerLocation: false,
        buttonActive: false
      },
      successMessage: "",
      errorMessage: ""
    }
  }

 

  submitAllocation = () => {
    /* 
      Make aN axios PUT request to http://localhost:2040/allocate/:distributorName with form data 
      and handle success and error cases 
      
    */
   this.setState({ successMessage: "", errorMessage: "" })

   //axios.put(url + this.props.match.params.distributorName, this.state.formValue)
   axios.put(url + this.state.formValue.distributorName, this.state.formValue)
       .then(response => {
         console.log(response)
           this.setState({ successMessage: response.data.message, errorMessage: "" });
       }).catch(error => {
         if(error.response) this.setState({ errorMessage: error.response.data.message, successMessage: "" });
        else this.setState({ errorMessage: "server error", successMessage: "" }); });
      }
      
  handleSubmit = (event) => {
    /* prevent page reload and invoke submitAllocation() method */
    event.preventDefault();
        this.submitAllocation();
  }

  handleChange = (event) => {
    /* 
      invoke whenever any change happens in any of the input fields
      and update form state with the value. Also, Inoke validateField() method to validate the entered value
    */
   const name=event.target.name;
   const value=event.target.value
   const newState=this.state.formValue
   switch(name){
     case "distributorName":
     newState.distributorName=value;
     break;
     case "purchaseDate":
     newState.purchaseDate=value;
     break;
     case "installationDate": 
     newState.installationDate=value;
     break;
     case  "customerName":
     newState.customerName=value;
     break;
     case "customerLocation":
     newState.customerLocation=value;
     break;
     default:
     break;

   }
   this.setState(newState);
   this.validateField(name,value)
  }

  validateField = (fieldName, value) => {
    /* Perform Validations and assign error messages, Also, set the value of buttonActive after validation of the field */
    let FormErrorMessage = this.state.formErrorMessage;
    let FormValid = this.state.formValid;

    switch (fieldName) {
      case "distributorName":
        
        if (String(value) === ""||value===null) {
          FormErrorMessage.distributorName = "field required";
          FormValid.distributorName= false;
        } else {
         FormErrorMessage.distributorName = "";
          FormValid[fieldName] = true;
        }
        break;
      case "purchaseDate":
      if (String(value) === ""||value===null) {
        FormErrorMessage.purchaseDate = "field required";
        FormValid.purchaseDate= false;
        } else if (!(new Date(value)>new Date(new Date().toDateString()))) {
          FormErrorMessage.purchaseDate = "Purchase date should be today or greater than todays date";
          FormValid.purchaseDate= false;
        } else {
          FormErrorMessage.purchaseDate = "";
          FormValid.purchaseDate= true;
        }
        break;
      case "installationDate":
        // const flightRegex = /^[A-Z]{3}-[0-9]{3}$/;
        const installationDate=new Date(value);
        const purchasedate=new Date(this.state.formValue.purchaseDate)
        console.log(purchasedate.getDate()+7);
        //purchasedate.setDate(purchasedate.getDate()+7)
        
        if (String(value) === ""||value===null) {
          FormErrorMessage.installationDate = "field required";
          FormValid.installationDate= false;
          } else if ((installationDate>=purchasedate && installationDate<=purchasedate.setDate(purchasedate.getDate()+7))) {
            FormErrorMessage.installationDate = "";
            FormValid.installationDate= true;
          } else {
            FormErrorMessage.installationDate = "Installation date should be after purchase date and within 7 days from purchase date";
            FormValid.installationDate= false;
           
          }
          break;
          case  "customerLocation":
          if (String(value) === ""||value===null) {
            FormErrorMessage.customerLocation = "field required";
            FormValid.customerLocation = false;
            } else if (!(String(value).match(/^[a-zA-Z][a-zA-Z ]{2,}$/))) {
              FormErrorMessage.customerLocation = "Please enter a valid Location";
              FormValid.customerLocation = false;
            } else {
              FormErrorMessage.customerLocation  = "";
              FormValid.customerLocation = true;
            }
            break;
            case  "customerName":
          if (String(value) === ""||value===null) {
            FormErrorMessage.customerName = "field required";
            FormValid.customerName= false;
            } else if (!(String(value).match(/^[a-zA-Z][a-zA-Z ]{3,}$/))) {
              FormErrorMessage.customerName = "Please enter a valid name";
              FormValid.customerName= false;
            } else {
              FormErrorMessage.customerName = "";
              FormValid.customerName= true;
            }
            break;


      default:
        break;
          }
    FormValid.buttonActive =
      FormValid.customerLocation &&
      FormValid.customerName &&
      FormValid.distributorName&& FormValid.installationDate && FormValid.purchaseDate
    this.setState({ formErrorMessage:FormErrorMessage, formValid: FormValid, successMessage: "" })
  }

  render() {
    return (
      <React.Fragment>
        {JSON.stringify(this.state.formValid)}
        <div className="CreateBooking ">
          <div className="container-fluid row">
            <div className="col-md-6 offset-md-3">
              <br />
              <div className="card">
                <div className="card-header bg-custom">
                  <h4>Allocation Form</h4>
                </div>
                <div className="card-body">
                  {/* create form as per the view given in screenshots */}
                  {/* Display success or error messages as given in QP */}
                  <form onSubmit={this.handleSubmit}>
                  <div className="form-group">
                    <label htmlFor="distributorName">Distributor Name </label>
                    <select
                      name="distributorName"
                      id="distributorName"
                      value={this.state.formValue.distributorName}
                      onChange={this.handleChange}
                      className="form-control">
                      <option value="" key="">--Select a Distributor--</option>
                      <option value="Suntek" key="1">Suntek</option>
                      <option value="A4solar" key="2">A4solar</option>
                      <option value="SupremeSolar" key="3">SupremeSolar</option>
                    </select>
                    <span name="distributorNameError" className="text-danger">
                      {this.state.formErrorMessage.distributorName}
                    </span>
                    <div className="form-group">
                    <label htmlFor="customerName">Customer Name</label>
                    <input
                      type="text"
                      name="customerName"
                      id="customerName"
                      placeholder="Enter Customer Name"
                      value={this.state.formValue.customerName}
                      onChange={this.handleChange}
                      className="form-control"
                    />
                    <span name="customerNameError" className="text-danger">
                      {this.state.formErrorMessage.customerName}
                    </span>
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="customerLocation">Customer Location </label>
                    <input
                      type="text"
                      name="customerLocation"
                      id="customerLocation"
                      placeholder="Enter Customer Location"
                      value={this.state.formValue.customerLocation}
                      onChange={this.handleChange}
                      className="form-control"
                    />
                    <span name="customerLocationError" className="text-danger">
                      {this.state.formErrorMessage.customerLocation}
                    </span>
                  </div>

                  <div className="form-group">
                    <label htmlFor="purchaseDate">Purchase Date</label>
                    <input
                      type="date"
                      name="purchaseDate"
                      id="purchaseDate"
                      placeholder="mm/dd/yyyy"
                      value={this.state.formValue.purchaseDate}
                      onChange={this.handleChange}
                      className="form-control"
                    />
                    <span name="purchaseDateError" className="text-danger">
                      {this.state.formErrorMessage.purchaseDate}
                    </span>
                  </div>

                  <div className="form-group">
                    <label htmlFor="installationDate">Installation Date</label>
                    <input
                      type="date"
                      name="installationDate"
                      id="installationDate"
                      placeholder="mm/dd/yyyy"
                      value={this.state.formValue.installationDate}
                      onChange={this.handleChange}
                      className="form-control"
                    />
                    <span name="installationDateError" className="text-danger">
                      {this.state.formErrorMessage.installationDate}
                    </span>
                  </div>

                  <button type="submit" className="btn btn-primary" name="allocateSolar"
                    disabled={!this.state.formValid.buttonActive}>Allocate Solar</button>
                    <br />
                <span name="successMessage" className="text-success text-bold">
                  {this.state.successMessage}
                </span>
                <span name="errorMessage" className="text-danger text-bold">
                  {this.state.errorMessage}
                </span>
                </div>
                </form>
                
              </div>
            </div>
          </div>
        </div>
        </div>
      </React.Fragment>
    );
  }
}

export default AllocateSolar;