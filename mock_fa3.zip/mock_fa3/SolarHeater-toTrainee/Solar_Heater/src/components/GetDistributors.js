import React, { Component } from "react";
import axios from "axios";
import "../App.css";

const url = "http://localhost:2040/findService/";

class GetDistributors extends Component {
  constructor(props) {
    super(props);
    this.state = {
      distributorData: [],
      form: {
        customerLocation: ""
      },
      formErrorMessage: {
        customerLocation: ""
      },
      formValid: {
        customerLocation: false,
        buttonActive: false
      },
      errorMessage: "",
      successMessage: ""
    };
  }

  handleSubmit = (event) => {
    /* prevent page reload and invoke fetchDistributorByLocation() method */
    event.preventDefault();
    this.fetchDistributorByLocation();
  }

  handleChange = (event) => {
    /* 
      invoke whenever any change happens in any of the input fields
      and update form state with the value. Also, Inoke validateField() method to validate the entered value
    */
    const name = event.target.name;
    const value = event.target.value
    const newState = this.state.form
    switch (name) {
      case "customerLocation":
        newState.customerLocation = value;
        break;
      default:
        break;

    }
    this.setState(newState);
    this.validateField(name, value)
  }

  validateField = (fieldName, value) => {
    /* Perform Validations and assign error messages, Also, set the value of buttonActive after validation of the field */
    let FormErrorMessage = this.state.formErrorMessage;
    let FormValid = this.state.formValid;
    switch (fieldName) {
      case "customerLocation":
        if (String(value) === "" || value === null) {
          FormErrorMessage.customerLocation = "field required";
          FormValid.customerLocation = false;
        } else if (!(String(value).match(/^[a-zA-Z][a-zA-Z\t]{2,}$/))) {
          FormErrorMessage.customerLocation = "Please enter a valid location";
          FormValid.customerLocation = false;
        } else {
          FormErrorMessage.customerLocation = "";
          FormValid.customerLocation = true;
        }
        break;
      default:
        break;
    }
    FormValid.buttonActive =
      FormValid.customerLocation
    this.setState({ formErrorMessage: FormErrorMessage, formValid: FormValid, successMessage: "" })
  }


  fetchDistributorByLocation = () => {
    /* 
      Send an AXIOS GET request to the url http://localhost:1050/findService/:customerLocation 
      to fetch all the distributors available in that location
      and handle the success and error cases appropriately 
    */

    axios.get(url + this.state.form.customerLocation)
      .then((response) => {
        console.log("hello i m anandita")
        console.log(response);
        this.setState({ distributorData: response.data, errorMessage: "" })
      })
      .catch(error => {
        console.log(error.response)
        if (error.response) {
          this.setState({ distributorData: [], errorMessage: error.response.data.message })
        } else {
          this.setState({ distributorData: [], errorMessage: "Server Error" })
        }
      })
  }

  render() {
    return (
      <React.Fragment>
        <div className="row">
          <div className="col-md-6 offset-md-3">
            <br />
            <div className="card">
              <div className="card-header bg-custom text-center">
                <h4>View Distributors</h4>
              </div>
              <div className="card-body view">
                {/* code here to get the view as shown in QP for GetDistributors component */}
                {/* display the distributors in an unordered list */}
                {/* Display error message if the server is not running */}
                <form onSubmit={this.handleSubmit}>
                  <div className="form-group">
                    <label htmlFor="customerLocation">Customer Location </label>
                    <input
                      type="text"
                      name="customerLocation"
                      id="customerLocation"
                      placeholder="Enter Customer Location"
                      value={this.state.form.customerLocation}
                      onChange={this.handleChange}
                      className="form-control"
                    />
                    <span name="customerLocationError" className="text-danger">
                      {this.state.formErrorMessage.customerLocation}
                    </span>
                  </div>

                  <button type="submit" className="btn btn-primary" name="getDistributors"
                    disabled={!this.state.formValid.buttonActive}>Get Distributors</button>
                </form>
                {this.state.distributorData.length>0&&<p className="text-success text-bold">distributors {this.state.form.customerLocation}</p>}
                {this.state.distributorData.length>0&&this.state.distributorData.map((data,index)=><li className="text-success text-bold" key={index}>{data}</li>)}
                <span name="successMessage" className="text-success text-bold">
                  {this.state.successMessage}
                </span>
                <span name="errorMessage" className="text-danger text-bold">
                  {this.state.errorMessage}
                </span>


              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default GetDistributors;